warning off;
global squasher data1 minx miny maxx maxy malags neuronxarg;
load hongkong_inflation_may2004;
malags = 4;
arlags = 3;
SQUASHER = 1;
ndraws = 500;
nrun1 = 1;
nnreg = 40;
maxiter =10000;
maxgen = 100;
tic;
lagyy = 0;
neuronxarg = 10;
y  = datanew(:,1);
x = datanew(:,2:end);
data1 = [y x];
miny = min(y);
maxy = max(y);
[rx, cx] = size(x);
for i = 1:cx,
    minx(i) = min(x(:,i));
    maxx(i) = max(x(:,i));
end
DATA = [y x];
rr = length(data1);
squasher = SQUASHER;    
alpha_boot = .05;
options = optimset('Display', 'off','MaxIter', maxiter);
popsize = 100; 
pc = .9; pmstart = 30; 
elite = 1; 
pdes = 0; 
maxgen1 = maxgen + 10; 
toler = .0001; 
fun1 = 'jerryautofun';
fun1a = 'jerryautofun_out';
fun2 = 'jerryautofun1';
fun2a = 'jerryautofun1_out';
fun3 = 'jerryautofun2'; 
fun3a = 'jerryautofun2_out';
global data1;
[nx, cx] = size(x);
for jjj = 1:nnreg,
jjj
midpoint = round(.5 * nx);
nparm =  3 * cx +  malags + 2;
betanetinit = randn(1,nparm);
nparmols =  cx+ malags+1;
nparmstrs = 2*cx + malags + 3;
betastrsinit = randn(1,nparmstrs);
betaolsinit = randn(1,nparmols);
beta0ols = gen7f(fun2, betaolsinit, popsize, maxgen);
beta0ols = fminunc(fun2, beta0ols, options);
[likols, yhatols,pderivols1] = feval(fun2, beta0ols);
yhatols1 = yhatols;
errorols1 = y -  yhatols1;
sseols1 = sumsqr(errorols1);
meansseols1 = mean(errorols1 .^2);
hqifols1 = rr * log(sseols1) + nparmols * log(log(rr));
rsqols1 = var(yhatols1) ./ var(y);
dwols1= durbinwatson(errorols1);
nlags = 12;
[jbstatols1, jbsigols1] = jarque(errorols1, 4);
[qstatols1, msigols1] = qstatlb(errorols1, 8, 1);
[qstatsqols1, msigsqols1] = qstatlb(errorols1.^2, 8, 1);
[junk1, lmstatols1, lmsigols1] = engleng(errorols1);
[nntestols1, nnsumols1] = wnntest1(errorols1, x, 5, 1000);
[bdsols1, bdssigols1] = bds1(errorols1);
LIK(1,jjj) = likols;
YHATOLS(:,jjj) = yhatols1;
ERROROLS(:,jjj) = errorols1;
RSQ1(1,jjj) =  rsqols1;
HQIF1(1,jjj) = [ hqifols1];
SSE1(1,jjj) = [sseols1];
DW1(1,jjj) = [ dwols1];
JB1(1,jjj) = [jbsigols1];
MSIG1(1,jjj) = [ msigols1];
MSIG21(1,jjj) = [ msigsqols1];
LMSIG1(1,jjj) = [ lmsigols1];
WNNSUM1(1,jjj) = [nnsumols1];
BDSSIG1(1,jjj) = [ bdssigols1];
PDERIVOLS(jjj,:) = [(pderivols1)];
indicatorols(jjj) = MSIG1(1,jjj);


beta1net = gen7f(fun1, betanetinit, popsize, maxgen);
beta1net = fminunc(fun1, beta1net, options);
[liknet, yhatnet1,pderiv1,neuron3] = feval(fun1, beta1net);
yhatnet1 = yhatnet1;
errornet1 = y - yhatnet1;
ssenet1 = sumsqr(errornet1);
meanssenet1 = mean(errornet1 .^2);
hqifnet1 = rr * log(ssenet1) + nparm * log(log(rr));
rsqnet1 = var(yhatnet1) ./ var(y);
dwnet1= durbinwatson(errornet1);
[jbstatnet1, jbsignet1] = jarque(errornet1, 4);
[qstatnet1, msignet1] = qstatlb(errornet1, 8, 1);
[qstatsqnet1, msigsqnet1] = qstatlb(errornet1.^2, 8, 1);
[junk1, lmstatnet1, lmsignet1] = engleng(errornet1);
[nntestnet1, nnsumnet1] = wnntest1(errornet1, x, 5, 1000);
[bdsnet1, bdssignet1] = bds1(errornet1);
LIK(2,jjj) = liknet;
NEURON3(:,jjj) = neuron3;
YHATNET(:,jjj) = yhatnet1;
ERRORNET(:,jjj) = errornet1;
RSQ1(2,jjj) = [rsqnet1];
HQIF1(2,jjj) = [ hqifnet1];
SSE1(2,jjj) = [ssenet1];
DW1(2,jjj) = [ dwnet1];
JB1(2,jjj) = [jbsignet1];
MSIG1(2,jjj) = [ msignet1];
MSIG21(2,jjj) = [msigsqnet1];
LMSIG1(2,jjj) = [lmsignet1];
WNNSUM1(2,jjj) = [nnsumnet1];
BDSSIG1(2,jjj) = [bdssignet1];
PDERIVNETMEAN(jjj,:) = [mean(pderiv1(2:end,:))];
PDERIVNETSTART(jjj,:) = pderiv1(2,:);
PDERIVNETMID(jjj,:) = pderiv1(midpoint,:);
PDERIVNETEND(jjj,:) = pderiv1(end,:);
indicator(jjj) = MSIG1(2,jjj);


beta1strs = gen7f(fun3, betastrsinit, popsize, maxgen);
beta1strs = fminunc(fun3, beta1strs, options);
[likstrs, yhatstrs1,pderiv1,neuron3] = feval(fun3, beta1strs);
yhatstrs1 = yhatstrs1;
errorstrs1 = y - yhatstrs1;
ssestrs1 = sumsqr(errorstrs1);
meanssestrs1 = mean(errorstrs1 .^2);
hqifstrs1 = rr * log(ssestrs1) + nparm * log(log(rr));
rsqstrs1 = var(yhatstrs1) ./ var(y);
dwstrs1= durbinwatson(errorstrs1);
[jbstatstrs1, jbsigstrs1] = jarque(errorstrs1, 4);
[qstatstrs1, msigstrs1] = qstatlb(errorstrs1, 8, 1);
[qstatsqstrs1, msigsqstrs1] = qstatlb(errorstrs1.^2, 8, 1);
[junk1, lmstatstrs1, lmsigstrs1] = engleng(errorstrs1);
[nnteststrs1, nnsumstrs1] = wnntest1(errorstrs1, x, 5, 1000);
[bdsstrs1, bdssigstrs1] = bds1(errorstrs1);
LIK(3,jjj) = likstrs;
NEURON3STRS(:,jjj) = neuron3;
YHATSTRS(:,jjj) = yhatstrs1;
ERRORSTRS(:,jjj) = errorstrs1;
RSQ1(3,jjj) = [rsqstrs1];
HQIF1(3,jjj) = [ hqifstrs1];
SSE1(3,jjj) = [ssestrs1];
DW1(3,jjj) = [ dwstrs1];
JB1(3,jjj) = [jbsigstrs1];
MSIG1(3,jjj) = [ msigstrs1]
MSIG21(3,jjj) = [msigsqstrs1]
LMSIG1(3,jjj) = [lmsigstrs1];
WNNSUM1(3,jjj) = [nnsumstrs1];
BDSSIG1(3,jjj) = [bdssigstrs1];
PDERIVSTRSMEAN(jjj,:) = [mean(pderiv1(2:end,:))];
PDERIVSTRSSTART(jjj,:) = pderiv1(2,:);
PDERIVSTRSMID(jjj,:) = pderiv1(midpoint,:);
PDERIVSTRSEND(jjj,:) = pderiv1(end,:);
indicatorstrs(jjj) = MSIG1(3,jjj);

end
[minsseols, indbestols] = max(indicatorols);
[minsse, indbest] = max(indicator);
[minssestrs, indbeststrs] = max(indicatorstrs);
LIKBEST = [LIK(1,indbestols); LIK(2,indbest); LIK(3,indbeststrs)];
RSQ = [RSQ1(1,indbestols); RSQ1(2,indbest); RSQ1(3,indbeststrs) ];
HQIF = [HQIF1(1,indbestols); HQIF1(2,indbest); HQIF1(3,indbeststrs)];
SSE = [SSE1(1,indbestols); SSE1(2,indbest); SSE1(3,indbeststrs)];
DW = [DW1(1,indbestols); DW1(2,indbest); DW1(3,indbeststrs)];
JB = [JB1(1,indbestols); JB1(2,indbest); JB1(3,indbeststrs)];
MSIG = [MSIG1(1,indbestols); MSIG1(2,indbest); MSIG1(3,indbeststrs)];
MSIG2 =[MSIG21(1,indbestols); MSIG21(2,indbest);MSIG21(3,indbeststrs)];
LMSIG =[LMSIG1(1,indbestols); LMSIG1(2,indbest); LMSIG1(3,indbeststrs)];
WNNSUM = [WNNSUM1(1,indbestols); WNNSUM1(2,indbest); WNNSUM1(3,indbeststrs)];
BDSSIG = [BDSSIG1(1,indbestols); BDSSIG1(2,indbest); BDSSIG1(3,indbeststrs)];
PDERIV = [PDERIVOLS(indbestols,:); PDERIVNETMEAN(indbest,:); PDERIVNETSTART(indbest,:); PDERIVNETMID(indbest,:); PDERIVNETEND(indbest,:);...
        PDERIVSTRSMEAN(indbeststrs,:); PDERIVSTRSSTART(indbeststrs,:); PDERIVSTRSMID(indbeststrs,:); PDERIVSTRSEND(indbeststrs,:)];
ERRORBEST = [ERROROLS(:,indbestols) ERRORNET(:,indbest) ERRORSTRS(:,indbeststrs)];
YHATBEST = [YHATOLS(:,indbestols) YHATNET(:,indbest) YHATSTRS(:,indbeststrs)];
NEURON3BEST = NEURON3(:,indbest);
NEURON3STRSBEST = NEURON3STRS(:,indbeststrs);

% Bootstrap Program
% Bootstrap Program
[nrow1, ncol1] = size(data1);
clear global squasher;

global squasher;
squasher = SQUASHER;
betaolsinit = beta0ols;
betanetinit = beta1net;
betastrsinit = beta1strs;
for i = 1:ndraws,
    i
clear global data1;
global data1;
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
errorshock = ERRORBEST(indexin,:);
[rr, cc] = size(data1);
data1 = [YHATBEST(:,1)+errorshock(:,1) x];
beta0_boot = gen7f(fun2, betaolsinit, popsize, maxgen);
beta0_boot = fminunc(fun2, beta0_boot, options);
betaolsinit = beta0_boot;
[errorols, yhatols, pderivols] = feval(fun2,beta0_boot);
PDERIVOLSBOOT(i,:) = pderivols;
clear global data1;
global data1;
data1 = [YHATBEST(:,2)+errorshock(:,2) x];
for j = 1:nrun1,
beta1_boot = gen7f(fun1, betanetinit, popsize, maxgen);
beta1_boot = fminunc(fun1, beta1_boot, options);
betanetinit = beta1_boot;
clear junkerr;
[error, yhat, pderiv] = feval(fun1,beta1_boot);
ERROR(j) = error;
BETA1_BOOT(j,:) = beta1_boot;
end;
[errorboot, indboot] = min(ERROR);
beta1_boot_best = BETA1_BOOT(indboot,:);
[error, yhat, pderiv] = feval(fun1,beta1_boot_best);
PDERIVNETBOOTSTART(i,:) = pderiv(2,:);
PDERIVNETBOOTMID(i,:) = pderiv(midpoint,:);
PDERIVNETBOOTEND(i,:) = pderiv(end,:);
PDERIVNETBOOTMEAN(i,:) = mean(pderiv);
clear global data1;
clear global data1;
global data1;
data1 = [YHATBEST(:,3)+errorshock(:,3) x];
for j = 1:nrun1,
beta2_boot = gen7f(fun3, betastrsinit, popsize, maxgen);
beta2_boot = fminunc(fun3, beta2_boot, options);
betastrsinit = beta2_boot;
clear junkerr;
[error, yhat, pderiv] = feval(fun3,beta2_boot);
ERROR(j) = error;
BETA2_BOOT(j,:) = beta2_boot;
end;
[errorboot, indboot] = min(ERROR);
beta2_boot_best = BETA2_BOOT(indboot,:);
[error, yhat, pderiv] = feval(fun3,beta2_boot_best);
PDERIVSTRSBOOTSTART(i,:) = pderiv(2,:);
PDERIVSTRSBOOTMID(i,:) = pderiv(midpoint,:);
PDERIVSTRSBOOTEND(i,:) = pderiv(end,:);
PDERIVSTRSBOOTMEAN(i,:) = mean(pderiv);
clear global data1;
end;
clear i

%  Out of sample accuracy...

nrow1x = round(.5 * nrow1);
nrun = nrow1 - nrow1x;
clear global squasher;
global squasher;
squasher = SQUASHER;

nrun1 = 1;
for i = 1:nrun,
    i
YY(i,:) = DATA(nrow1x+i,1);
datax = [DATA(1:nrow1x+i,1) DATA(1:nrow1x+i,2:end)];
yy = datax(:,1); xx = datax(:,2:end);
data11 = [yy xx];
[rdata1, cdata1] = size(data11);

for j = 1:nrun1,
  
clear global data1;
global data1;
data1 = data11(1:nrow1x+i-1,:);
[rdata1, cdata1] = size(data1);
beta0real = gen7f(fun2, betaolsinit, popsize, maxgen);
beta0real = fminunc(fun2, beta0real, options);
betaolsinit = beta0real;
beta1real = gen7f(fun1, betanetinit, popsize, maxgen);
beta1real = fminunc(fun1, beta1real, options);
betanetinit = beta1real;
beta2real = gen7f(fun3, betastrsinit, popsize, maxgen);
beta2real = fminunc(fun3, beta2real, options);
betastrsinit = beta2real;

clear junkerr;
clear global data1;
global data1;
data1 =  data11(nrow1x+i,:);
[errorolsreal, YYOLS] = feval(fun2a, beta0real);
youtrealols1(i,j) = YYOLS(end,:);
[error1real, YYNET, YYNETNN] = feval(fun1a, beta1real);
youtrealnet1(i,j) = YYNET(end,:);
youtrealnet1nn(i,j) = YYNETNN(end,:);
[error1real, YYSTRS] = feval(fun3a, beta2real);
youtrealstrs1(i,j) = YYSTRS(end,:);
if isnan(youtrealnet1(i,j)) == 1, youtrealnet1(i,j) = 0; end;
if isnan(youtrealnet1nn(i,j)) == 1, youtrealnet1nn(i,j) = 0; end;
if isnan(youtrealols1(i,j)) == 1, youtrealols1(i,j) = 0; end;
if isnan(youtrealstrs1(i,j)) == 1, youtrealstrs1(i,j) = 0; end;


end
youtrealols(i,:) = median(youtrealols1(i,:));
errorrealols1(i,:) = YY(i,:) - youtrealols(i,:);

% youtrealnet(i,:) = trimmean([youtrealnet1(i,:) youtrealols(i,:)],10);

youtrealnet(i,:) = median([youtrealnet1(i,:)]);
youtrealnetnn(i,:) = median([youtrealnet1nn(i,:)]);

errorrealnet1(i,:) = YY(i,:) - youtrealnet(i,:);

youtrealstrs(i,:) = median([youtrealstrs1(i,:)]);
errorrealstrs1(i,:) = YY(i,:) - youtrealstrs(i,:);


clear datax yy xx data11 Y X XX  p t pderivnet;
clear global data1;
end
rmsqrealols = sqrt(mean(errorrealols1 .^2));
rmsqrealnet1 = sqrt(mean(errorrealnet1 .^2));
rmsqrealstrs1 = sqrt(mean(errorrealstrs1 .^2));
WESTP = length(errorrealols1);
WESTLIN = mean(errorrealols1 .^2);
WESTNET = mean(errorrealnet1 .^2);
WESTNETADJ = WESTNET - mean(youtrealnetnn .^2);
WESTF = WESTLIN - WESTNETADJ;
WESTV = 4 * mean((errorrealols1 .* youtrealnetnn).^2);
WESTSTAT = sqrt(WESTP) * WESTF;
WESTPVALUE = 1- normcdf(WESTSTAT, 0, WESTV);


RMSQREAL = [rmsqrealols; rmsqrealnet1; rmsqrealstrs1];
for jj = 1:5,
    [DMSTAT(jj,1), DMSIG(jj,1)] = dieboldmar(errorrealols1, errorrealnet1,jj);
    [DMSTAT1(jj,1), DMSIG1(jj,1)] = dieboldmar(errorrealols1, errorrealstrs1,jj);
    [DMSTAT2(jj,1), DMSIG2(jj,1)] = dieboldmar(errorrealstrs1, errorrealnet1,jj);
end
[DAOLS, DAPVALUEOLS, SROLS] = datest(YY, youtrealols);
[DANET, DAPALUENET, SRNET] = datest(YY, youtrealnet);
[DASTRS, DAPALUESTRS, SRSTRS] = datest(YY, youtrealstrs);


PDERIVOLSBOOT1= excise(PDERIVOLSBOOT);
PDERIVOLSBOOT2 = sort(PDERIVOLSBOOT1);
alpha_boot = .05;
lower = round(.5 * alpha_boot * ndraws) + 1;
upper = round((1-.5 * alpha_boot) * ndraws);
PDERIVOLSBOOT3 = PDERIVOLSBOOT2(lower:upper,:);

PDERIVNETBOOT1START= sort(excise(PDERIVNETBOOTSTART));
PDERIVNETBOOT1MID= sort(excise(PDERIVNETBOOTMID));
PDERIVNETBOOT1END= sort(excise(PDERIVNETBOOTEND));
PDERIVNETBOOT1MEAN= sort(excise(PDERIVNETBOOTMEAN));
PDERIVNETBOOT3START = PDERIVNETBOOT1START(lower:upper,:);
PDERIVNETBOOT3MID = PDERIVNETBOOT1MID(lower:upper,:);
PDERIVNETBOOT3END = PDERIVNETBOOT1END(lower:upper,:);
PDERIVNETBOOT3MEAN = PDERIVNETBOOT1MEAN(lower:upper,:);

PDERIVSTRSBOOT1START= sort(excise(PDERIVSTRSBOOTSTART));
PDERIVSTRSBOOT1MID= sort(excise(PDERIVSTRSBOOTMID));
PDERIVSTRSBOOT1END= sort(excise(PDERIVSTRSBOOTEND));
PDERIVSTRSBOOT1MEAN= sort(excise(PDERIVSTRSBOOTMEAN));
PDERIVSTRSBOOT3START = PDERIVSTRSBOOT1START(lower:upper,:);
PDERIVSTRSBOOT3MID = PDERIVSTRSBOOT1MID(lower:upper,:);
PDERIVSTRSBOOT3END = PDERIVSTRSBOOT1END(lower:upper,:);
PDERIVSTRSBOOT3MEAN = PDERIVSTRSBOOT1MEAN(lower:upper,:);



for i = 1:cx;
    junky = PDERIVOLSBOOT3(:,i)>0;  junkyy = sum(junky)/length(junky); ppvalue1(1,i) = junkyy; JUNKY(i) = junkyy;
end;
for i = 1:cx;
    junkystart = PDERIVNETBOOT3START(:,i)>0;  junkyystart = sum(junkystart)/length(junkystart); ppvalue1(2,i) = junkyystart;  JUNKYSTART(i)=junkyystart;
    junkymid = PDERIVNETBOOT3MID(:,i)>0;  junkyymid = sum(junkymid)/length(junkymid); ppvalue1(3,i) = junkyymid; JUNKYMID(i) = junkyymid;
    junkyend = PDERIVNETBOOT3END(:,i)>0;  junkyyend = sum(junkyend)/length(junkyend); ppvalue1(4,i) = junkyyend; JUNKYEND(i) = junkyyend;
    junkymean = PDERIVNETBOOT3MEAN(:,i)>0;  junkyymean = sum(junkymean)/length(junkymean); ppvalue1(5,i) = junkyymean; JUNKYMEAN(i) = junkyymean;
    
    junkystart = PDERIVSTRSBOOT3START(:,i)>0;  junkyystart = sum(junkystart)/length(junkystart); ppvalue1(6,i) = junkyystart;  JUNKZSTART(i)=junkyystart;
    junkymid = PDERIVSTRSBOOT3MID(:,i)>0;  junkyymid = sum(junkymid)/length(junkymid); ppvalue1(7,i) = junkyymid; JUNKZMID(i) = junkyymid;
    junkyend = PDERIVSTRSBOOT3END(:,i)>0;  junkyyend = sum(junkyend)/length(junkyend); ppvalue1(8,i) = junkyyend; JUNKZEND(i) = junkyyend;
    junkymean = PDERIVSTRSBOOT3MEAN(:,i)>0;  junkyymean = sum(junkymean)/length(junkymean); ppvalue1(9,i) = junkyymean; JUNKZMEAN(i) = junkyymean;

end;

FINALDERIVSTAT = [JUNKY; JUNKYMEAN; JUNKYSTART; JUNKYMID; JUNKYEND;  JUNKZMEAN; JUNKZSTART; JUNKZMID; JUNKZEND];


toc;
runtime = toc;
runtime1 = runtime / 60;
runtime2 = runtime / 60;
save honkonginflation_may2004_run8;























