load texasbankingdata;



warning off;
for j= 1:1,
limit = .5;
[nrow1, ncol1] = size(data);
%   Ouputs:
%         [DISCRIMRES, NETRES, LOGITRES, PROBITRES,...
%         PDERIVNET, PDERIVLOG, PDERIVPROB,betalp,...
%         betanet , Ahatin, Ahatout] =...
%      classnet(assetx,coldep,percent,errweight,limit,info,gendum,maxgen, helge);
%       output: insample error percetn, out of sample error percent, 
%       DSC, NN, LOG, PROBIT,  then...derivatives for net, log,prob, then
%       betalp,   coefficients and t stat for logit and probit models
%       betanet coefficients  for neural net
%       Actual predicted probabilities for net, logit, probit: in and out
%   Inputs:
%        Input matrix,
%        column of dep variable,  
%        percent of data for in sample,
%        error weighting for false positive and false negatives
%        limit for classification, usually .5
%        info: neurons in layers, n1, n2, n3
%        gendum:  
%            genetic algorith with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%        maxgen:  number of generations for ga
%        helge:  scaling function
maxgen1 = 100;
ndraws = 50;
[discres, netres, logitres, probitres, pderivnet, pderivlogit, pderivprobit, betalp,...
      betanet, Ahatin, Ahatout] = classnet(data, 23, 1,.5, limit,[1 3 0 0], 1, maxgen1, 0);
pderivnet1 = pderivnet(end-1:end,:);
pderivlogit1 = pderivlogit(end-1:end,:);
pderivnet1 = pderivnet(end-1:end,:);
RESS(:,:,j) = [discres; netres; logitres; probitres];
end
for i = 1:ndraws,
    i
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
for j=1:nrow1, 
    if sum(ismember(indexin,j)) > 0,
        indexout(j,:) = NaN;
    else indexout(j,:) = j;
    end
end
indexout = excise(indexout);
data1in = data(indexin,:);
[rrin, ccin] = size(data1in);
dataout = data(indexout,:);
[rrout, ccout] = size(dataout);
percentin = rrin /(rrin + rrout);
mydatanew = [data1in; dataout];
[discres1, netres1, logitres1, probitres1] = classnet(mydatanew, 23, percentin,.5, limit,[1 3 0 0], 1, maxgen1, 0);
clear mydatanrew data1in dataout;
DISCRES(:,:,i) = discres1;
NETRES(:,:,i) = netres1;
LOGITRES(:,:,i) = logitres1;
PROBITRES(:,:,i) = probitres1;
end;
for i = 1:ndraws,
discresout_final(i,:) = DISCRES(2,:,i);
netresout_final(i,:) = NETRES(2,:,i);
logitresout_final(i,:) = LOGITRES(2,:,i);
probitresout_final(i,:) = PROBITRES(2,:,i);
end
discresout_final_mean = mean(discresout_final);
netresout_final_mean = mean(netresout_final);
logitresout_final_mean = mean(logitresout_final);
probitresout_final_mean = mean(probitresout_final);
discresout_final_mean = mean(discresout_final);
netresout_final_std = std(netresout_final);
logitresout_final_std = std(logitresout_final);
probitresout_final_std = std(probitresout_final);

[dmstat1, dmsig1] = dieboldmar(probitresout_final(:,3), logitresout_final(:,3),1);
[dmstat2, dmsig2] = dieboldmar(probitresout_final(:,3), netresout_final(:,3),1);
[dmstat3, dmsig3] = dieboldmar(logitresout_final(:,3), netresout_final(:,3),1);


save texasfinance_run6;

