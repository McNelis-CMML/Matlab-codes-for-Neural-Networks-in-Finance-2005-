
load USHKCAPFLOOR.mat
load USHKCAPFLOOR_ALL_run11.mat;
USDATA = DATA(:,1:6);
HKDATA = DATA(:,7:12);
encoder = 5;
decoder = 5;
nnpc = 1;
nnpc2 = 2;

% Ouputs:
%       output: 
%               sse,rsq,rmsqe,bai_ng, SCORE, SCOREOUT, NPC,NPCOUT,
%               foutput,exitflag, ydep, A1, A3, A3n, pc, beta
%  				
%   Inputs:
%        Input matrix,
%        percent of data for in sample,
%        nencoders, ncomponents, ndecoders
%        gendum:  
%            genetic algorithm with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%        maxgen:  number of generations for ga
%        maxgen1:  number of epochs or iterations for function optimizer
%        dummy for squasher, 1 for helge, 2 for DeLeo, 3 for Matlab linear, 0 for none
%        optional initial beta
gendum = 1;

maxgen = 50;
maxgen1 = 5000;
% maxgen =  500;
% maxgen1 = 15000;
squasher = 3;
% [sse_us, rsq_us, rmsq_us, baing_us, score_us, scoreout, npc_us, npcout, foutput_us, exitflag_us, ydep_us, a1_us, a3_us, a3n_us, pc_us, beta_us]= ...
%         nonlinpc(USDATA, 1, encoder, nnpc, decoder, gendum, maxgen, maxgen1, squasher);
%     
% [sse_hk, rsq_hk, rmsq_hk, baing_hk, score_hk, scoreout, npc_hk, npcout, foutput_hk, exitflag_hk, ydep_hk, a1_hk, a3_hk, a3n_hk, pc_hk, beta_hk] = ...
%         nonlinpc(HKDATA, 1, encoder, nnpc, decoder, gendum, maxgen, maxgen1, squasher);
    
% [sse_alltwo, rsq_alltwo, rmsq_alltwo, baing_alltwo, score_alltwo, scoreout, npc_alltwo, npcout, foutput_alltwo, exitflag_alltwo, ydep_alltwo, a1_alltwo, a3_alltwo, a3n_alltwo, pc_alltwo, beta_alltwo] = ...
%         nonlinpc(DATA, 1, encoder, nnpc2, decoder, gendum, maxgen, maxgen1, squasher);
%     
% [sse_allone, rsq_allone, rmsq_allone, baing_allone, score_allone, scoreout, npc_allone, npcout, foutput_allone, exitflag_allone, ydep_allone, a1_allone, a3_allone, a3n_allone, pc_allone, beta_allone]= ...
%         nonlinpc(DATA, 1, encoder, nnpc, decoder, gendum, maxgen, maxgen1, squasher);
    

[nrow1, ncol1] = size(DATA);
percentin1 = .80;
nrow1x = round(percentin1 * nrow1);
nrun = nrow1 - nrow1x;
beta_us00 = beta_us;
beta_hk00 = beta_hk;
for i = 1:nrun,
    i
DATANEW = DATA(1:nrow1x+i,:);
percentin = (nrow1x+i-1)/(nrow1x+i);
USDATANEW = DATANEW(:,1:6);
HKDATANEW = DATANEW(:,7:12);
[sse_us0, rsq_us0, rmsq_us0, baing_us0, score_us0, scoreout_us0, npc_us0, npcout_us0, foutput_us0, exitflag_us0, ...
    ydep_us0, a1_us0, a3_us0, a3n_us0, pc_us0, beta_us0, ERROUTLIN0_us, ERROUTNPC0_us, YOUT_us, YOUTLIN_us, YOUTNET_us]= ...
        nonlinpc(USDATANEW, percentin, encoder, nnpc, decoder, gendum, maxgen, maxgen1, squasher,beta_us00);
 

[sse_hk0, rsq_hk0, rmsq_hk0, baing_hk0, score_hk0, scoreout_hk0, npc_hk0, npcout_hk0, foutput_hk0, exitflag_hk0, ...
    ydep_hk0, a1_hk0, a3_hk0, a3n_hk0, pc_hk0, beta_hk0, ERROUTLIN0_hk, ERROUTNPC0_hk, YOUT_hk, YOUTLIN_hk, YOUTNET_hk] = ...
        nonlinpc(HKDATANEW, percentin, encoder, nnpc, decoder, gendum, maxgen, maxgen1, squasher,beta_hk00);
    
beta_us00 = beta_us0;
beta_hk00 = beta_hk0;

YOUTUS(i,:) = YOUT_us;
YOUTLINUS(i,:) = YOUTLIN_us;
YOUTNPCUS(i,:) = YOUTNET_us;

YOUTHK(i,:) = YOUT_hk;
YOUTLINHK(i,:) = YOUTLIN_hk;
YOUTNPCHK(i,:) = YOUTNET_hk;

ERRORLINUS(i,:) = ERROUTLIN0_us;
ERRORNPCUS(i,:) = ERROUTNPC0_us;
ERRORLINHK(i,:) = ERROUTLIN0_hk;
ERRORNPCHK(i,:) = ERROUTNPC0_hk;
RSQ00(:,:,i) = [rsq_us0; rsq_hk0]
ERRDATA = [ERRORLINUS(i,:); ERRORNPCUS(i,:); ERRORLINHK(i,:); ERRORNPCHK(i,:)]
gendum = 0;
maxgen1 = 5000;
end

for j = 1:6,
    RMSQLINUS(j) = sqrt(mean(ERRORLINUS(:,j) .^2));
    RMSQNPCUS(j) = sqrt(mean(ERRORNPCUS(:,j) .^2));
    RMSQLINHK(j) = sqrt(mean(ERRORLINHK(:,j) .^2));
    RMSQNPCHK(j) = sqrt(mean(ERRORNPCHK(:,j) .^2));
end
for j = 1:6,
    for jj = 1:5,
         [DMSTATUS(jj,j), DMSIGUS(jj,j)] = dieboldmar(ERRORLINUS(:,j), ERRORNPCUS(:,j),jj);
         [DMSTATHK(jj,j), DMSIGHK(jj,j)] = dieboldmar(ERRORLINHK(:,j), ERRORNPCHK(:,j),jj);
     end
 end
save USHKCAPFLOOR_ALL_run77.mat;
   







    




    