load crises6;
clear x y;
comment = 'bop bank infl spg gdpgrow credgrow m1m0 depr finlib realint arg voliv braz chil col den finland indo isreal malay mex norway peru phil spain swed thail turkey uruguay venez';
dummies = 'asiandum eurodum latindum';
x = [data(:,[2 3 4 5 6 7 10]) asiandum latindum];
y = data(:,1);
data = [y x];
neurons = 4;
helge = 2;
warning off;
maxgen1 = 20;
ndraws = 50;

for j= 1:1,
limit = .5;
[nrow1, ncol1] = size(data);
%   Ouputs:
%         [DISCRIMRES, NETRES, LOGITRES, PROBITRES,...
%         PDERIVNET, PDERIVLOG, PDERIVPROB,betalp,...
%         betanet , Ahatin, Ahatout] =...
%      classnet(assetx,coldep,percent,errweight,limit,info,gendum,maxgen, helge);
%       output: insample error percetn, out of sample error percent, 
%       DSC, NN, LOG, PROBIT,  then...derivatives for net, log,prob, then
%       betalp,   coefficients and t stat for logit and probit models
%       betanet coefficients  for neural net
%       Actual predicted probabilities for net, logit, probit: in and out
%   Inputs:
%        Input matrix,
%        column of dep variable,  
%        percent of data for in sample,
%        error weighting for false positive and false negatives
%        limit for classification, usually .5
%        info: neurons in layers, n1, n2, n3
%        gendum:  
%            genetic algorith with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%        maxgen:  number of generations for ga
%        helge:  scaling function
[discres, netres, logitres, probitres, gompitres, pderivnet, pderivlogit, pderivprobit, ...
      pderivgompit, betalp,...
      betanet, Ahatin, Ahatout, LIKELIHOOD] = ...
      classnet(data, 1, 1,.5, limit, [1 neurons 0 0], 1, maxgen1, helge);
PDERIVALL = [pderivnet; pderivlogit; pderivprobit; pderivgompit];
RESS(:,:,j) = [discres; netres; logitres; probitres; gompitres];
end
for i = 1:ndraws,
    i
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
for j=1:nrow1, 
    if sum(ismember(indexin,j)) > 0,
        indexout(j,:) = NaN;
    else indexout(j,:) = j;
    end
end
indexout = excise(indexout);
data1in = data(indexin,:);
[rrin, ccin] = size(data1in);
dataout = data(indexout,:);
[rrout, ccout] = size(dataout);
percentin = rrin /(rrin + rrout);
mydatanew = [data1in; dataout];
[discres1, netres1, logitres1, probitres1, gompitres1, pderivnet11, pderivlogit11, pderivprobit11, pderivgompit11] = ...
    classnet(mydatanew, 1, percentin,.5, limit,[1 neurons 0 0], 1, maxgen1, helge);

pderivnet1(i,:) = (pderivnet11);
pderivlogit1(i,:) = (pderivlogit11);
pderivprobit1(i,:) = (pderivprobit11);
pderivgompit1(i,:) = (pderivgompit11);



clear mydatanrew data1in dataout;
DISCRES(:,:,i) = discres1;
NETRES(:,:,i) = netres1;
LOGITRES(:,:,i) = logitres1;
PROBITRES(:,:,i) = probitres1;
GOMPITRES(:,:,i) = gompitres1;
end;
for i = 1:ndraws,
discresout_final(i,:) = DISCRES(2,:,i);
netresout_final(i,:) = NETRES(2,:,i);
logitresout_final(i,:) = LOGITRES(2,:,i);
probitresout_final(i,:) = PROBITRES(2,:,i);
gompitresout_final(i,:) = GOMPITRES(2,:,i);
end
pderivnet1sort = sort(pderivnet1);
pderivlogit1sort = sort(pderivlogit1);
pderivprobit1sort = sort(pderivprobit1);
pderivgompit1sort = sort(pderivgompit1);


x = data(:,2:end);
[rx, cx] = size(x);
for i= 1:cx,
junknet = pderivnet1sort(:,i)>0;  junknet1 = sum(junknet)/length(junknet); ppvalue1(1,i) = junknet1; 
junklogit = pderivlogit1sort(:,i)>0;  junklogit1 = sum(junklogit)/length(junklogit); ppvalue1(2,i) = junklogit1; 
junkprobit = pderivprobit1sort(:,i)>0;  junkprobit1 = sum(junkprobit)/length(junkprobit); ppvalue1(3,i) = junkprobit1; 
junkgompit = pderivgompit1sort(:,i)>0;  junkgompit1 = sum(junkgompit)/length(junkgompit); ppvalue1(4,i) = junkgompit1; 
end


discresout_final_mean = mean(discresout_final);
netresout_final_mean = mean(netresout_final);
logitresout_final_mean = mean(logitresout_final);
probitresout_final_mean = mean(probitresout_final);
discresout_final_mean = mean(discresout_final);
netresout_final_std = std(netresout_final);
logitresout_final_std = std(logitresout_final);
probitresout_final_std = std(probitresout_final);

[dmstat1, dmsig1] = dieboldmar(probitresout_final(:,3), logitresout_final(:,3),1);
[dmstat2, dmsig2] = dieboldmar(probitresout_final(:,3), netresout_final(:,3),1);
[dmstat3, dmsig3] = dieboldmar(logitresout_final(:,3), netresout_final(:,3),1);

save bopcrises6_run2;

