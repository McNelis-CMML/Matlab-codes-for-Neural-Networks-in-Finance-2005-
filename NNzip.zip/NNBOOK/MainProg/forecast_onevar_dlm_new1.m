NRUN = 10;
NDRAWS = 10;
jjj = 1;
T = 500;
randn('seed',0);
x(1,:) = .5;
y(1,:) = 1;
sigma = .5;
eta = randn(T,1);

for i = 2:T,
    x(i,:) = .99 * x(i-1,:) + eta(i,:);
    y(i,:) = x(i-1,1) * x(i,:);
end
% y =  diff(y);
% x = diff(x);
[ut1, ut2] = unitroot(y);
if abs(ut2(1)) < 2, 
    y = diff(y);
    else y = y;
end
indexcrit = 400;
index = 1:T;  index = index';
logdum = 0;
diffdum = 0;
% 
tic

nntwarn off;
warning off;
randomex = 0;
grtdummy = 0;
   % 1 for feedforward, 2 for jump connection, 3 for recurrent network
   % 4 for ridglet, 5 for radial basis function
dumbootstrap = 0;
dumjoint = 0;
nrun = NRUN;
generations = 25;
epochs = 10000;
delta = 1e-04;
lagy = 1:nrun;
helge = HELGE * ones(1,nrun);
netdum1 = NETDUM * ones(1,nrun);
neurons1 = NEURONS1 * ones(1,nrun);


y = y(1:end,:);
ly = y;
for j = 1:nrun, 
  
netdum = netdum1(j);
index1 = index(5:end,:);

ydata = [y(5:end,:) mylag(y,4)];


[rydata, cydata] = size(ydata);
ydata1 = ydata;
mydata = ydata1;
[zrow, zcol] = size(mydata);
index2 = index1;
mydata = mydata;
[rmydata, cmydata] = size(mydata);

mydata1 = mydata;
[rowmydata1, colmydata1] = size(mydata1);
index3 = index2;
[rindex, cindex] = size(index3);

for kk = 1:rindex, 
    if index3(kk) <= indexcrit, dumindex(kk) = 1;
    else dumindex(kk) = 0; 
    end; 
end;
% percentin = sum(dumindex) / rindex;

index4 = dumindex';
index5 = selif(index4, 1);
[index5r, index5c] = size(index5);
diffrow =  rowmydata1 - index5r;
mydataxxx = mydata1(1:index5r,:);
Y = mydataxxx(:,1);
X = mydataxxx(:,2:end);
BETA = (X'*X)\X'*Y;
ERRORY = Y - X * BETA;
nrow = length(Y);
ncol = length(BETA);
SSR = ERRORY' * ERRORY;
loglik1 = -.5 * nrow * (1+log(2*pi)) - .5 * nrow * SSR / nrow;
rrsq = 1 - var(ERRORY)/var(Y);
hqif(j) = -2 * (loglik1/nrow) + 2 * ncol * log(log(nrow))/nrow;
bif(j) = -2 * (loglik1/nrow) + 2 * ncol * (log(nrow))/nrow;
[beta, tstat, rsq, dw, jbstat, engle, qstat1, qstat2] = ols1(X,Y);
[nntest, nnsum] = wnntest1(ERRORY, X, 5, 1000);
[bdsw, bdssig] = bds1(ERRORY);
clear SSR Y X BEAT ERRORY nrow ncol;
[minval1, ind1] = min(hqif);
junkin(:,j) = [qstat1(2); qstat2(2); engle(2); jbstat(2); nnsum; bdssig];
end;


lagy1 = ind1;
junk = junkin(:,ind1);



nrun = NRUN;
epochs = 1000;
delta = 1e-04;
lagy =  zeros(1,nrun);
helge = HELGE * ones(1,nrun);
netdum1 = NETDUM * ones(1,nrun);
neurons1 = NEURONS1 * ones(1,nrun);
for j = 1:nrun, 
netdum = netdum1(j);
index1 = index(2:end,:);
for jjjj = 1: diffrow, 
% randn('state', jjjj * j);
% rand('state', jjjj * j);
mydata2 = mydata1(1:index5r+jjjj,:);
if netdum < 3, 
percentin = (index5r+jjjj-1) / (index5r+jjjj);
else percentin = (index5r+jjjj-2) / (index5r+jjjj);
end

derdum = 0; 
endog = [1];
delay = zeros(1,1);
[rendog, cendog] = size(endog);
[rdelay, cdelay] = size(delay);
[junk1, junk2] = size(mydata1);
lags = zeros(1,5) ;

if sum(delay) == 0, 
    ndim = cendog; 
else ndim = cendog * cdelay; 
end;

mydata1inf = mydata2;

     
    if netdum == 1,
           [sse, rsq,rmsq, hqif, pderiv, yyyhat, yout] = ffnet9(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    elseif netdum == 2, 
          [sse, rsq,rmsq, hqif, pderiv,yyyhat, yout] = ffnet9_jump(mydata1inf, endog, percentin, ...
          lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    else netdum == 3,
          [sse, rsq,rmsq, hqif, pderiv, yyyhat, yout] = ffnet9_elman(mydata1inf, endog, percentin, ...
          lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    end
    
 interval = 12;


for i = 1:ndim,
   erroroutls(:,i) = yout(:,ndim+i) - yout(:,i); 
   erroroutnet(:,i) = yout(:,2*ndim+i) - yout(:,i);
   
   rrmsq(1,i) = sqrt(mean(erroroutls(:,i) .^2));
   rrmsq(2,i) = sqrt(mean(erroroutnet(:,i) .^2));
   
end
  
    YOUT(jjjj,:,j) = yout(end,:);
    ERROROUTLS(jjjj,j) = erroroutls(end,:);
    ERROROUTNET(jjjj,j) = erroroutnet(end,:);
    RRMSQ_LS(j) = sqrt(mean(ERROROUTLS(:,j) .^2));
    RRMSQ_NET(j) = sqrt(mean(ERROROUTNET(:,j) .^2));
%        PDERIV(:,:,j) = pder;
    clear erroroutls erroroutnet yout yhat pder;

end


for jj = 1:5,
 [DMSTAT(jj,j), DMSIG(jj,j)] = ...
       dieboldmar(ERROROUTLS(:,j), ERROROUTNET(:,j), jj-1);
end
 [da1, dapvalue1, sr1] = datest(YOUT(:,1,j), YOUT(:,2,j));
 [da2, dapvalue2, sr2] = datest(YOUT(:,1,j), YOUT(:,3,j));
 DA1(j) = da1;
 DA2(j) = da2;
 DAPVALUE1(j) = dapvalue1;
 DAPVALUE2(j) = dapvalue2;
 SR1(j) = sr1
 SR2(j) = sr2
 RMSQ_LS(j) = sqrt(mean(ERROROUTLS(:,j) .^2));
RMSQ_NET(j) = sqrt(mean(ERROROUTNET(:,j) .^2));
RRMSQ(:,j) = [RMSQ_LS(j); RMSQ_NET(j)];
SR(:,j) = [SR1(j); SR2(j)];
RSQ(:,j) = rsq;
STATSOUT(:,j)= [j; RSQ(:,j); RRMSQ(:,j); SR(:,j); DMSIG(:,j)];

end
for j = 1:nrun,
    YOUTNET(:,j) = YOUT(:,3,j);
end
kkk = length(YOUTNET(:,1));

if nrun > 5,
for i = 1:kkk,
YOUTNETGRANGERM(i,1) = trimmean([YOUTNET(i,:)], (2/nrun) * 100);
YOUTNETGRANGERM(i,2)= median([YOUTNET(i,:)]);
YOUTNETGRANGERM(i,3)= mean([YOUTNET(i,:)]);
YOUTNETGRANGERM(i,4)= max([YOUTNET(i,:)])- min([YOUTNET(i,:)]);
YOUTNETGRANGERM(i,5)= YOUT(i,2,1);
YOUTNETGRANGER(i,:) = median(YOUTNETGRANGERM(i,1:5));
end
else YOUTNETGRANGER(i,:) = mean(YOUTNET(i,:));
end

ERROROUTNETG=  YOUT(:,1) - YOUTNETGRANGER;
RMSQ_NETG = sqrt(mean(ERROROUTNETG .^2));

for jj = 1:5,
 [DMSTATG(jj,1), DMSIGG(jj,1)] = ...
       dieboldmar(ERROROUTLS(:,1), ERROROUTNETG(:,1), jj-1);
end
 [da2, dapvalue2, sr2] = datest(YOUT(:,1,1), YOUTNETGRANGER);
 DA1G = DA1(j);
 DA2G = da2;
 DAPVALUE1G = DAPVALUE1(j);
 DAPVALUE2G = dapvalue2;
 SR1G = SR1(j)
 SR2G= sr2;
 SRG = [SR1G; SR2G];
 RMSQ_LSG = sqrt(mean(ERROROUTLS(:,j) .^2));
RRMSQG = [RMSQ_LS(j); RMSQ_NETG];
SRG = [SR1G; SR2G];
RSQG= RSQ(:,j);
STATSOUTG1= [j+1; RSQG; RRMSQG; SRG; DMSIGG];



ndraws = NDRAWS;
% Bootstrap Program
[nrow1, ncol1] = size(mydata1);
mydata1inf = mydata1;
percentin = 1;
       
    if netdum == 1,  [sse, rsq,rmsq, hqif, pderiv, yhat, yyyout] = ffnet9(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    elseif netdum == 2, 
          [sse, rsq,rmsq, hqif, pderiv, yhat, yyyout] = ffnet9_jump(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    else netdum == 3,
         [sse, rsq,rmsq, hqif, pderiv, yhat, yyyout] = ffnet9_elman(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(j) 0 0], 1, generations, epochs, helge(j), derdum, delta);
    
    end    
errorls = yhat(:,1) - yhat(:,2);
errornet = yhat(:,1) - yhat(:,3);
meansseols = mean(errorls .^2);
meanssenet1 = mean(errornet .^2);

for i = 1:ndraws,
    i
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
for j=1:nrow1, 
    if sum(ismember(indexin,j)) > 0,
        indexout(j,:) = NaN;
    else indexout(j,:) = j;
    end
end
indexout = excise(indexout);
data1in = mydata1(indexin,:);
[rrin, ccin] = size(data1in);
dataout = mydata1(indexout,:);
[rrout, ccout] = size(dataout);
percentin = rrin /(rrin + rrout);
clear mydata1inf;
mydata1inf = [data1in; dataout];
for rr = 1:NRUN,
    if netdum == 1,  [sse, rsq,rmsq, hqif, pderiv, yyyhat, yout] = ffnet9(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(rr) 0 0], 1, generations, epochs, helge(rr), derdum, delta);
    elseif netdum == 2, 
          [sse, rsq,rmsq, hqif, pderiv, tstatn, yyyhat, yout] = ffnet9_jump(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(rr) 0 0], 1, generations, epochs, helge(rr), derdum, delta);
    else netdum == 3,
         [sse, rsq,rmsq, hqif, pderiv, tstatn, yyyhat, yout] = ffnet9_elman(mydata1inf, endog, percentin, ...
           lags, delay, [1 neurons1(rr) 0 0], 1, generations, epochs, helge(rr), derdum, delta);
   end
    YOUTB(:,rr) = yout(:,3);
end
YOUTBB = YOUTB';
youtboot1(1,:) = mean(YOUTBB);
youtboot1(2,:) = trimmean(YOUTBB, 20);
youtboot1(3,:) = median(YOUTBB);
youtboot1(4,:) = max(YOUTBB) - min(YOUTBB);
youtboot1(5,:) = yout(:,2)';
youtboot = median(youtboot1);
youtboot = youtboot';




errorols_boot = yout(:,1) - youtboot;
rmsqols_boot(i) = sqrt(mean(errorols_boot .^2));
SQLS(i,:) = mean(errorols_boot .^2);
if isnan(SQLS(i,:)) == 1, SQLS(i,:) = []; 
else SQLS(i,:) = SQLS(i,:); 
end;


errornet1_boot = yout(:,1) - youtboot;
rmsqnet1_boot(i) = sqrt(mean(errornet1_boot .^2));
SQNET1(i,:) = mean(errornet1_boot .^2);
if isnan(SQNET1(i,:)) == 1, SQNET1(i,:) = []; 
else SQNET1(i,:) = SQNET1(i,:); 
end;
clear yout youtboot youtboot1 YOUTBB YOUTB;


end;

epsilon0_ls = mean(SQLS);
epsilon0_net1 = mean(SQNET1);

omega632_ls = .632 * (epsilon0_ls - meansseols);
omega632_net1 = .632 * (epsilon0_net1 - meanssenet1);


ssebootstrap_ls =  meansseols + omega632_ls;
ssebootstrap_net1 = meanssenet1 + omega632_net1;

bootdata = [ssebootstrap_ls; ssebootstrap_net1];
bootdataratio = bootdata(2:end,:) ./ bootdata(1,:);
[minboot, bootranking] = sort(bootdata);

toc;
runtime = toc;
runtime1 = runtime / 60;
runtime2 = runtime1 / 60;


