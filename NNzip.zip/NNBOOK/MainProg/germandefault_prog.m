load germandefault;
global NEPOCH;
clear data;
data = [y x];
neurons = 3;
helge = 3;
warning off;
ndraws = 100;
gendum = 1;
maxgen1 = 50;
NEPOCH = 4000;

for j= 1:1,
limit = .5;
[nrow1, ncol1] = size(data);
%   Ouputs:
%         [DISCRIMRES, NETRES, LOGITRES, PROBITRES,...
%         PDERIVNET, PDERIVLOG, PDERIVPROB,betalp,...
%         betanet , Ahatin, Ahatout] =...
%      classnet(assetx,coldep,percent,errweight,limit,info,gendum,maxgen, helge);
%       output: insample error percetn, out of sample error percent, 
%       DSC, NN, LOG, PROBIT,  then...derivatives for net, log,prob, then
%       betalp,   coefficients and t stat for logit and probit models
%       betanet coefficients  for neural net
%       Actual predicted probabilities for net, logit, probit: in and out
%   Inputs:
%        Input matrix,
%        column of dep variable,  
%        percent of data for in sample,
%        error weighting for false positive and false negatives
%        limit for classification, usually .5
%        info: neurons in layers, n1, n2, n3
%        gendum:  
%            genetic algorith with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%        maxgen:  number of generations for ga
%        helge:  scaling function
[discres, netres, logitres, probitres, gompitres, pderivnet, pderivlogit, pderivprobit, ...
      pderivgompit, pderivnetf, pderivlogitf, pderivprobitf, pderivgompitf,...
      Ahatin, Ahatout, LIKELIHOOD, beta, beta1, beta2, beta3] = ...
      classnet(data, 1, 1,.5, limit, [1 neurons 0 0], gendum, maxgen1, helge);
pderivnetmean = mean(pderivnetf);
pderivlogitmean = mean(pderivlogitf);
pderivprobitmean = mean(pderivprobitf);
pderivgompitmean = mean(pderivgompitf); 
PDERIV1 = [pderivnet; pderivlogit; pderivprobit; pderivgompit];
PDERIVF = [pderivnetmean; pderivlogitmean; pderivprobitmean; pderivgompitmean];
PDERIV1
PDERIVF
RESS(:,:,j) = [discres; netres; logitres; probitres; gompitres];
end

% Out-of-Sample Accuracy
for i = 1:ndraws,
    i
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
for j=1:nrow1, 
    if sum(ismember(indexin,j)) > 0,
        indexout(j,:) = NaN;
    else indexout(j,:) = j;
    end
end
indexout = excise(indexout);
data1in = data(indexin,:);
[rrin, ccin] = size(data1in);
dataout = data(indexout,:);
[rrout, ccout] = size(dataout);
percentin = rrin /(rrin + rrout);
mydatanew = [data1in; dataout];
[discres1, netres1, logitres1, probitres1, gompitres1, pderivnet1, pderivlogit1, pderivprobit1, pderivgompit1,pderivnet2, pderivlogit2, pderivprobit2, pderivgompit2] = ...
    classnet(mydatanew, 1, percentin,.5, limit,[1 neurons 0 0], gendum, maxgen1, helge, beta, beta1, beta2, beta3);
pderivnet1mean(i,:) = (pderivnet1);
pderivlogit1mean(i,:) = (pderivlogit1);
pderivprobit1mean(i,:) = (pderivprobit1);
pderivgompit1mean(i,:) = (pderivgompit1);

pderivnet2mean(i,:) = mean(excise(pderivnet2));
pderivlogit2mean(i,:) = mean(excise(pderivlogit2));
pderivprobit2mean(i,:) = mean(excise(pderivprobit2));
pderivgompit2mean(i,:) = mean(excise(pderivgompit2));




clear mydatanrew data1in dataout;
DISCRES(:,:,i) = discres1;
NETRES(:,:,i) = netres1;
LOGITRES(:,:,i) = logitres1;
PROBITRES(:,:,i) = probitres1;
GOMPITRES(:,:,i) = gompitres1;
end;
for i = 1:ndraws,
discresout_final(i,:) = DISCRES(2,:,i);
netresout_final(i,:) = NETRES(2,:,i);
logitresout_final(i,:) = LOGITRES(2,:,i);
probitresout_final(i,:) = PROBITRES(2,:,i);
gompitresout_final(i,:) = GOMPITRES(2,:,i);
end
pderivnet1meansort = sort(excise(pderivnet1mean));
pderivlogit1meansort = sort(excise(pderivlogit1mean));
pderivprobit1meansort = sort(excise(pderivprobit1mean));
pderivgompit1meansort = sort(excise(pderivgompit1mean));

pderivnet2meansort = sort(excise(pderivnet2mean));
pderivlogit2meansort = sort(excise(pderivlogit2mean));
pderivprobit2meansort = sort(excise(pderivprobit2mean));
pderivgompit2meansort = sort(excise(pderivgompit2mean));





x = data(:,2:end);
[rx, cx] = size(x);
for i= 1:cx,
junknetmean = pderivnet1meansort(:,i)>0;  junknetmean1 = sum(junknetmean)/length(junknetmean); ppvalue1(1,i) = junknetmean1; 
junklogitmean = pderivlogit1meansort(:,i)>0;  junklogitmean1 = sum(junklogitmean)/length(junklogitmean); ppvalue1(2,i) = junklogitmean1; 
junkprobitmean = pderivprobit1meansort(:,i)>0;  junkprobitmean1 = sum(junkprobitmean)/length(junkprobitmean); ppvalue1(3,i) = junkprobitmean1; 
junkgompitmean = pderivgompit1meansort(:,i)>0;  junkgompitmean1 = sum(junkgompitmean)/length(junkgompitmean); ppvalue1(4,i) = junkgompitmean1; 
end

for i= 1:cx,
junknetmean = pderivnet2meansort(:,i)>0;  junknetmean1 = sum(junknetmean)/length(junknetmean); ppvalue2(1,i) = junknetmean1; 
junklogitmean = pderivlogit2meansort(:,i)>0;  junklogitmean1 = sum(junklogitmean)/length(junklogitmean); ppvalue2(2,i) = junklogitmean1; 
junkprobitmean = pderivprobit2meansort(:,i)>0;  junkprobitmean1 = sum(junkprobitmean)/length(junkprobitmean); ppvalue2(3,i) = junkprobitmean1; 
junkgompitmean = pderivgompit2meansort(:,i)>0;  junkgompitmean1 = sum(junkgompitmean)/length(junkgompitmean); ppvalue2(4,i) = junkgompitmean1; 
end



discresout_final_mean = mean(discresout_final);
netresout_final_mean = mean(netresout_final);
logitresout_final_mean = mean(logitresout_final);
probitresout_final_mean = mean(probitresout_final);
gompitresout_final_mean = mean(gompitresout_final);
netresout_final_std = std(netresout_final);
logitresout_final_std = std(logitresout_final);
probitresout_final_std = std(probitresout_final);
gompitresout_final_std = std(gompitresout_final);

[dmstat1, dmsig1] = dieboldmar(discresout_final(:,3), netresout_final(:,3),1);
[dmstat2, dmsig2] = dieboldmar(discresout_final(:,3), logitresout_final(:,3),1);
[dmstat3, dmsig3] = dieboldmar(discresout_final(:,3), probitresout_final(:,3),1);
[dmstat4, dmsig4] = dieboldmar(discresout_final(:,3), gompitresout_final(:,3),1);

[dmstat5, dmsig5] = dieboldmar(probitresout_final(:,3), logitresout_final(:,3),1);
[dmstat6, dmsig6] = dieboldmar(probitresout_final(:,3), netresout_final(:,3),1);
[dmstat7, dmsig7] = dieboldmar(probitresout_final(:,3), gompitresout_final(:,3),1);

[dmstat8, dmsig8] = dieboldmar(logitresout_final(:,3), netresout_final(:,3),1);
[dmstat9, dmsig9] = dieboldmar(logitresout_final(:,3), gompitresout_final(:,3),1);


[dmstat10, dmsig10] = dieboldmar(gompitresout_final(:,3), netresout_final(:,3),1);






save germandefault_run4;

