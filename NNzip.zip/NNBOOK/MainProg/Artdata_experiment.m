% clear all;
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 1;
% forecast_onevar_dlm_new1;
% save forecast_onevar_dlm_run2;
clear all
NEURONS1 = 3;
HELGE = 3;  % matlab squasher 
NETDUM = 1;
forecast_onevar_markovmodel_new1;
save forecast_onevar_markovmodel_run3;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 1;
% forecast_onevar_scmodel_new1;
% save forecast_onevar_scmodel_run2;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 1;
% forecast_onevar_setarmodel_new1;
% save forecast_onevar_setarmodel_run2;
% clear all;
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 1;
% forecast_onevar_svjdmodel_new1
% save forecast_onevar_svjdmodel_run2;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 1;
% forecast_onevar_targarchmodel_new1
% save forecast_onevar_targarchmodel_run2;
% clear all;


% clear all;
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_dlm_new1;
% save forecast_onevar_dlm_run3;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_markovmodel_new1;
% save forecast_onevar_markovmodel_run3;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_scmodel_new1;
% save forecast_onevar_scmodel_run3;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_setarmodel_new1;
% save forecast_onevar_setarmodel_run3;
% clear all;
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_svjdmodel_new1
% save forecast_onevar_svjdmodel_run3;
% clear all
% NEURONS1 = 3;
% HELGE = 3;  % matlab squasher 
% NETDUM = 2;
% forecast_onevar_targarchmodel_new1
% save forecast_onevar_targarchmodel_run3;
% clear all;
% 
% 
% 
% 
