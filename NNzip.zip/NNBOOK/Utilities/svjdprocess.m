function [yhats, theta, yhat] = svjdprocess(betab,hh,rr);
%  Inputs:  beta, hh, rr
%  Simulation of a SVJD process
%  beta(1) = alpha
%  beta(2) = beta
%  beta(3) = delta
%  beta(4) = kbar
%  beta(5) = lambda
%  beta(6) = mu
%  beta(7) = sigmav
%  beta(8) = rho
%  Output:  yhats, theta, yhat
%  dS/S = (mu-lambda*kbar)dt + sqrt(V)dZ + k dq
%  dV = (%alpha-beta*V)dt + sigmav *sqrt(v) dZv
%
%  cov(dZ,dZv)=corr(dZ,dZv)=rho dt
%  prob(dq=1) = lambda dt,   ln(1+k) ~ N(ln(1+kbar) - 0.5 delta^2,delta^2
% ___________________________________________________________________
% The risk neutral process is given as follows:
% dS/S = (b-lambdastar*kbarstar) dt + sqrt(V) dZstar + kstar dqstar
% dV = (alpha-betastar*V) dt + sigmav *sqrt(v) d Zv
% cov(dZ,dZv)=corr(dZ,dZv)=rho dt
% prob(dqstar=1) = lambdastar dt,   E(kstar)=kbarstar, var(kstar)=delta

h = 1/hh;
z = randn(rr,1);
zk = randn(rr,1);
poiss1 = poissrnd(h, rr,1);
poiss2 = poissrnd(2*h, rr,1);
poiss3 = poissrnd(3*h, rr,1);
poiss4 = poissrnd(4*h, rr,1);
v(1,1) = .00001;
k(1,1) = 0;
alpha = abs(betab(1));
beta = abs(betab(2));
if beta > 1, beta = .95; else beta = beta; end;
delta = abs(betab(3));
kbar = abs(betab(4));
lambda = round(abs(betab(5)))+1;
if lambda > 4, lambda = 4; else lambda = lambda; end;
mu = betab(6);
sigmav = abs(betab(7));
rho = betab(8);
h = 1/12;
for i = 2: rr,
   kx(i,1) =  zk(i,1)* delta + log(1+kbar) - .5 * delta ^ 2;
   k(i,1) = kx(i,1);
   if lambda == 1, poissz(i,1) = poiss1(i,1); elseif lambda ==2, poissz(i,1) = poiss2(i,1);
      elseif lambda == 3, poissz(i,1) = poiss3(i,1); else poissz(i,1) = poiss4(i,1); end
   yhat(i,1) = (mu - lambda * kbar) * h + sqrt(v(i-1,:)) * z(i,1)+ k(i,1) * poissz(i,1);
   if ~ isreal(yhat(i,1)), yhat(i,1) = 1000; else yhat(i,1) = (yhat(i,1));  end
   v(i,1) = v(i-1,1) + (alpha - beta * v(i-1,1)) * h + sigmav * sqrt(v(i-1,1)) * rho * z(i,1);
   if v(i,1) < 0, v(i,1) = .001; else v(i,1) = v(i,1); end;
end
[yhats, f1hat] = ker(yhat);
f1hat = f1hat / sum(f1hat);
jump = k .* poissz;
junk1 = 1 + mean(jump);
junk2 = cov(k, jump); 
junk3 = junk2(1,2);
lambdastar = lambda * junk1;
kbarstar = kbar + junk3 / junk1;
theta = [lambdastar kbarstar delta alpha beta sigmav rho mu];
 