function [ymat, xmat] = mylagvv(data, lagv, coldep, delay);
%  sets up matrix of one or more dependent variables, with
%  variables delays, variable lags
%  Input: data matrix, lagv, coldep, delay
%  Output:  dependent matrix, and independent variables matrix;
%  Arrange delay from smallest to largest;
maxdelay = max(delay);
mindelay = min(delay);
[rc cc] = size(coldep);
[rd cd] = size(delay);
diffdelay = maxdelay - delay;
ydep1 = [];
% [ydep xdata] = mylagv(data, lagv, coldep(1), delay(1));
% ydep1 = ydep(1:end-diffdelay(1));
for i = 1:cc,
   for j = 1:cd;
      [ydep, xdata] = mylagv(data, lagv, coldep(i), delay(j));
         ydepx = ydep(1:end-diffdelay(j),:);
         ydep1 = [ydep1 ydepx];
      end
   end
   
      
   ymat = ydep1;
   xmat = xdata;
      





