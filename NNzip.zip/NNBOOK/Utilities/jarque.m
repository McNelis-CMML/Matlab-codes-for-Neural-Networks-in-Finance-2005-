function [jbstat, msig] = jarque(y,k);
% Jarque-Bera statistic with marginal significance level, y input, k regressors
[t,c] = size(y);
K = kurtosis(y);
S = skewness(y);
dgf = t-k;
jbstat = (dgf/6) * (S ^2 + .25 * (K - 3) ^ 2);
msig = 1 - chi2cdf(jbstat,2);