function [nntest, nnsum] = wnntest1(resid, x, k, nrun);
%  While Neural Net Test for Hidden Non-linearities
%  inputs: datmat: input matrix, with y in first column, x's in rest
%  k # of neuron regressors to generate
%  nrun # of runs
%  output:  nntest, nnsum (no of times significance below .1)
for j = 1:nrun,
yy = resid;
[row col] =size(x);
row1 = row;
alpha = randn(col, k);
N = x * alpha;
n = 1 ./ (1 + exp(N));
beta1 = (n'*n)\n'*yy;
yyhat = n * beta1;
rsq(j) = (yyhat'*yyhat)/(yy'*yy);
fstat1(j) = (rsq(j)/k)/((1-rsq(j))/(row1-k));
critv(j) = fcdf(fstat1(j), k, row1-k);
pvalue(j) = 1 - critv(j);
end
nntest = [rsq' fstat1' pvalue' ];
pvalue = pvalue';
% plot([ones(nrun,1) * .10  pvalue]); pause
junk = zeros(nrun,1); for j = 1:nrun, if pvalue(j,1) <= .10, junk(j,1) = 1; end
end
nnsum = sum(junk);