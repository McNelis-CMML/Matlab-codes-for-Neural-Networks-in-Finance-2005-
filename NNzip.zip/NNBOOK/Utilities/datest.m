function [dastat, dapvalue, SR] = datest(y, yhat);
% Pesaran Timmermann test of directional accuracy for out of sample forecasts
% Input: y, yhat
% dastat, dapvalue, Success Ratio
[nn, rr] = size(y);
yy = y .* yhat;
Indic1 = gt(yy,0);
SR = mean(Indic1);
P = gt(y,0);
Phat = gt(yhat,0);
Pmean = mean(P);
Phatmean = mean(Phat);
SRI = Pmean * Phatmean + (1-Pmean) * (1-Phatmean);
varsri =  (2 * Phatmean - 1) ^2 * Pmean * (1-Pmean) + ...
    (2*Pmean-1) ^2 * Phatmean * (1-Phatmean) + ...
    (4/nn) * Pmean * Phatmean * (1-Pmean) * (1-Phatmean);
varsri = varsri / nn;
varsr = SRI * (1-SRI) * inv(nn);
DAnum = SR - SRI;
vjunk = varsr - varsri;
vjunk = abs(vjunk);
DAdenom = sqrt(vjunk);
dastat = DAnum / DAdenom;
dapvalue = 1 - normcdf(dastat);



    
     