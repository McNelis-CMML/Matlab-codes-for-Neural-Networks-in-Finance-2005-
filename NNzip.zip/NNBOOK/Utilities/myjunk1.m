% Create random regressors, constant term, 
     % and dependent variable
     for i = 1:1000,
     randn('state',i);
     xxx = randn(1000,1);
     x1 = ones(1000,1);
     x = [x1 xxx];
     y = sin(xxx).^2 + exp(-xxx);
     % Compute ols coefficients and diagnostics
     [beta, tstat, rsq, dw, jbstat, engle, ...
     lbox, mcli] = ols1(x,y);
     % Obtain residuals
     residuals = y - x * beta;
     sse = sum(residuals .^2);
     nn = length(residuals);
     kk = length(beta);
     % Hannan-Quinn Information Criterion
     k = 2;
     hqif = log(sse/nn) + k * log(log(nn))/nn;
     % Set up Lee-White-Granger test
     neurons = 5;
     nruns = 1000;
     % Nonlinearity Test
     [nntest, nnsum] = wnntest1(residuals, x, neurons, nruns);
     % BDS Nonlinearity Test
     [W, SIG] = bds1(residuals);
     RSQ(i) = rsq;
     DW(i) = dw;
     JBSIG(i) = jbstat(2);
     ENGLE(i) = engle(2);
     LBOX(i) = lbox(2);
     MCLI(i) = mcli(2);
     NNSUM(i) = nnsum;
     BDSSIG(i) = SIG;
     HQIF(i) = hqif;
     SSE(i) = sse;
    end