function pderivn1 = logsigder1(pbar,A3mean, gamma,gamma0, omega, omega0);
% pderivn = logsigder(pbar, gamma, omega, omega0);
nnbar = omega0 + omega * pbar;
nnbar = logsig(nnbar);
nbar = nnbar .* (1-nnbar);
nbar = gamma .* nbar';
nbar1 = logsig(gamma * (omega0 + omega * pbar) + gamma0);
pderivn1 = A3mean .* (1-A3mean) * nbar * omega;