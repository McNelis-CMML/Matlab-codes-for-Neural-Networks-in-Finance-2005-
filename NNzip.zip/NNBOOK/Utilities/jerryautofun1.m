function [error, yhat, pderiv] = jerryautofun1(beta);
global data1 squasher malags;
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
ny = length(y);
yhat1 = y; 
ehat(1:malags,1) = zeros(malags,1);
xx0 = x * beta(1:cx)' + ones(ny,1) * beta(cx+1);
for i = malags+1:ny, 
EXX = ehat(i-malags:i-1,:);
yhat1(i,:) =  xx0(i,:) +  beta(cx + 2: end) * EXX;
ehat(i,:) = y(i,:) - yhat1(i,:);
end;
    
nparm = cx + malags + 1;
error = y - yhat1;
error = mean(error .^2);
sigma = error/ nparm;  
% T = length(yhat1);          
% loglik = -.5 * T * log(2 * pi) - .5 * T * log(sigma) - .5 * error /sigma;

% error = -loglik;
yhat = yhat1; 
for i = 1:cx,
pderiv(:,i) = beta(i); 
end;





