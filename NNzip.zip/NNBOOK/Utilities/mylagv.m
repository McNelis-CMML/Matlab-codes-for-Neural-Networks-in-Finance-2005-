function [ydep, xdata] = mylagv(data, lagv, coldep, delay);
% Creates a lag structure of data for variables lages on the columns
% Input: data, lagv, lagv must be of dimension 1:columns of data
% coldep: column of dependent variable in data
% delay factor:forecast one period (0), or one week or one month
% Output:  ydep and xdata: dependent variable and independent variables
[rr cc] = size(data);
rr = max(lagv);
data1 = mylag(data, rr);
dd =1:rr:rr*cc;
mydata = data1(:,1:lagv(1));
for i = 2:cc,
   datax = data1(:,dd(i):dd(i)+lagv(i)-1);
   mydata = [mydata datax];
end;
maxdelay = max(delay);
ydep = data(rr+delay+1:end, coldep);
xdata = mydata(1:end-delay,:);
