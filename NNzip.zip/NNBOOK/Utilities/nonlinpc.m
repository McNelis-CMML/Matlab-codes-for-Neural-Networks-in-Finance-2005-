function [sse,rsq,rmsqe,bai_ng, SCORE, SCOREOUT, NPC,NPCOUT, foutput,exitflag, ydep, A1, A3, A3n, pc, beta,...
    err11, err31, yout, yhatls1, yhatnet1] = nonlinpc(assetx,percent,nencoders, ncomponents, ...
    ndecoders,gendum,maxgen, maxgen1, helge, beta);
   
  
      

% Ouputs:
%     output: 
%             sse,rsq,rmsqe,bai_ng, SCORE, SCOREOUT, NPC,NPCOUT,
%             foutput,exitflag, ydep, A1, A3, A3n, pc, beta
%				
% Inputs:
%      Input matrix,
%      percent of data for in sample,
%      nencoders, ncomponents, ndecoders
%      gendum:  
%          genetic algorithm with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%      maxgen:  number of generations for ga
%      maxgen1:  number of epochs or iterations for function optimizer
%      dummy for squasher, 1 for helge, 2 for DeLeo, 3 for Matlab linear, 0 for none
%      optional initial beta
	

global P T nlayer nneuron1 nneuron2 nneuron3;
warning off;
nntwarn off;
fun = 'nonlinpcfun';
info(1) = 3;
info(2) = nencoders;
info(3) = ncomponents;
info(4) = ndecoders;
nlayer = info(1);
nneuron1 = info(2);
nneuron2 = info(3);
nneuron3 = info(4);
popsize = 100; pc = .9; pdes = 0; toler = .001; elite = 1;
[rr cc] = size(assetx);
% nlag = 1;   % number of lags and arguments.
yrhat = [assetx];

   y = assetx;
   x = assetx;

yxmat = [y x];
   [nrow ncol] = size(x);
   [nrowy ncoly] = size(y);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = [ x(1:nrow1,:)];
[nrow ncol] = size(x);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = x(1:nrow1,:);
smin = .1;
smax = .9;
[rx, cx] = size(x);
[ry, cy] = size(y);
maxy = max(y);
miny = min(y);
maxx = max(x);
minx = min(x);
meany = mean(y);
sigy = std(y);
yz = detrend(y,0) ./ kron(ones(rx,1), sigy);
meanx = mean(x);
sigx = std(x);
xz = detrend(x,0) ./ kron(ones(rx,1),sigx);;
for i = 1:cy,
   ys(:,i) = hsquasher(y(:,i), smax, smin);
   yss(:,i) = 1./(1+exp(-(yz(:,i))));
end
for i = 1:cx,
   xs(:,i) = hsquasher(x(:,i), smax, smin);
   xss(:,i) = 1 ./ (1+ exp(-(xz(:,i))));
end

if helge == 0, PN = x; TN = y; 
    elseif helge == 1, PN = xs; TN = ys;
    elseif helge == 2, PN = xss; TN = yss;
    else 
   PP = x; TT = y;
        for i = 1:cx,
        PN(:,i) = (PP(:,i)-minx(i))./(maxx(i)-minx(i));
        end
        
        for i = 1:cy,
        TN(:,i) = (TT(:,i)-miny(i))./(maxy(i)-miny(i));
        end    
end
Praw = xx;
Traw = yy;
P = PN(1:nrow1,:);
T = TN(1:nrow1,:);
[rowp, colp] = size(P);
Pprime = P;
[pc, score, latent, tsquare] = princomp(Pprime);
SCORE = score(:,1:info(3));
SCOREPRIME1= SCORE;
SCORE = SCORE;

[W1] = inv(SCOREPRIME1' * SCOREPRIME1) * SCOREPRIME1' *Traw;
[junkr, junkc] = size(W1);
junk1 = junkr * junkc;
A1 = SCOREPRIME1 * W1;
A11 = A1;
TTraw = Traw;
[junkr, junkc] = size(TTraw);
A111 = A11 + kron(ones(junkr,1), mean(TTraw));
err1 = TTraw - A111; 
sse1 = sum(err1 .^ 2);
Als = A111;
yhatls = Als;
[yyr yyc] = size(yhatls);
err1 = yy - yhatls; 
ssrsq1 = ones(1,yyc) - var(err1) ./ var(yy);
sse1 = sum(err1 .^ 2);
hqols = nrow1 * log(sse1) + (ncol+1) * log(log(nrow1));
bai_ng_ols = log(sse1) + junk1 * ((nrow1 + ncol)/(nrow1 * ncol)) * log((nrow1*ncol)/(nrow1+ncol));
[rp,cp] = size(P);
nparm = nneuron1 * cp + nneuron1 + nneuron1 * nneuron2 + nneuron2 + nneuron2 * nneuron3 +  nneuron3 + nneuron3 * ncoly + ncoly;
nepoch = maxgen1; scale = 1; 
if nargin == 8, 
    beta0 = beta, 
    else beta0 = randn(1,nparm); 
end;
tp = [25, nepoch, .02, .01, 1.07, .7, .9, 1.04]; 
pm = .33; elite = 1; pdes = 0; 
if gendum >= 1, beta = ...
   gen7f(fun,beta0,popsize,maxgen); 
end
[criterion,sse3,g,A3,NPC,W3,b3,W4,b4, W5, b5, W6, b6] = feval(fun,beta);
if gendum <= 1,
    delta = .001;
    options = optimset('Display', 'iter','MaxFunEvals', nepoch, 'MaxIter', nepoch,...
   'TolFun', delta);
    [beta,foutput,exitflag] = fminunc(fun, beta, options);
    [criterion,sse3x,g,A3, NPC, W3,b3,W4,b4, W5, b5, W6, b6] = feval(fun,beta);
    else W3=W3; b3 = b3; W4 = W4; b4 = b4; W5 = W5, b5 = b5, W6 = W6, b6 = b6; 
end
if helge == 0, A3n = A3; 
    elseif helge == 1, A3 = A3;
        for i = 1:cy,
        A3x(:,i) = helgeyx(A3(:,i), maxy(i), miny(i),smax,smin);
        end
    A3 = A3;
    A3n = A3x; 
    elseif helge == 2, A3 = A3;
    A3x = -log(1./A3- ones(size(A3)));
    A3x = real(A3x); [junkr, junkc] = size(A3x);
    A3x = kron(ones(junkr,1),meany) + A3x .* kron(ones(junkr,1),sigy);
    A3 = A3;
    A3n = A3x; A3n = real(A3n);
    else 
        for i = 1:cy,
        A3n(:,i) = A3(:,i)* (maxy(i)-miny(i)) + miny(i);
        end
end
yhatnet = A3n;
ydep = yy;
err3 = ydep - yhatnet;
sse3 = sum(err3 .^2);
hqnet = nrow1 .* log(sse3) + (nparm) * log(log(nrow1));
bai_ng_net = log(sse3) + nparm * ((nrow1 + ncol)/(nrow1 * ncol)) * log((nrow1*ncol)/(nrow1+ncol));
ssrsq3 = ones(1,yyc) - var(err3) ./ var(yy);
sse = [sse1; sse3];
hqif = [hqols; hqnet];
bai_ng = [bai_ng_ols; bai_ng_net];
ssrsq = [ssrsq1; ssrsq3];
rsq = ssrsq;
if percent == 1,
    rmsqe = [];
    SCOREOUT = [];
    NPCOUT = [];
    else xout  = [x(nrow11:nrow,:)];
    yout = y(nrow11:nrow,:);
    [n1 c1] = size(yout);
    SCOREOUT = xout * pc(:,1:info(3));
    SCOREOUTPRIME = SCOREOUT;
    Toutraw = yout;
    T1 = TN(nrow1+1:end,:);
    P1 = PN(nrow1+1:end,:);
    A11 = SCOREOUTPRIME *W1;
    yhatls1 = A11;
    err11 = yout - yhatls1;
    err11sq = err11 .^2;
    rmsqe1 = sqrt(mean(err11sq));
   
%     A31 = P1 * W3+ kron(ones(length(P1),1),b3);
    A31 = P1 * W3 + b3;
    A31 = 1./(1+exp(-A31));
    A31 = A31 * W4 + b4;
    A31 = 1./(1+exp(-A31));
    NPCOUT = A31;
    A31 = A31 * W5 + b5;
    A31 = 1./(1+exp(-A31));
    A31 = A31 * W6 + b6;
        if helge == 0, yhatnet1 = A31;
        elseif helge == 1, A31z = A31;
            for i = 1:cy,
            A31x(:,i) = helgeyx(A31z(:,i),maxy(i), miny(i), smax, smin);
            end
        A31net = A31x; 
        yhatnet1 = A31net;
        elseif helge == 2,
        A31z = A31;
        A31x = -log(1./A31z - ones(size(A31z)));
        A31x = real(A31x);
        A31x = kron(ones(n1,1),meany) + A31x .* kron(ones(n1,1), sigy);
        A31net = A31x; 
        yhatnet1 = A31net;
        else  
            for i = 1:cy,
                A31net(:,i) = A31(:,i) .* (maxy(i)-miny(i)) + miny(i);
            end
   	    yhatnet1 = A31net;
        end
    err31 = yout-yhatnet1;
    err31sq = err31 .^2;
    rmsqe3 = (mean(err31sq)) .^.5;
    rmsqe = [rmsqe1; rmsqe3];
end
clear global P T nlayer nneuron1 nneuron2 nneuron3;