function  txx = chebjudd(x, degree);
% Output:  matrix of Chebchev polynomial expansion
% Input:  x, degree of expansion
[rr, cx] = size(x);
txx(:,1) = ones(rr,1);
txx(:,2) = x;
for i = 3:degree,
    txx(:,i) = 2 .* x .* txx(:,i-1) - txx(:,i-2);
end
txx = txx(:,2:end);