function [yrx,xxxx, betax, tbetax, tcritv, ssr,rsq, crsq, dw,fstat1, critv, infoc] = myvar(datmat, nendog, nlag, delay);
% specify datmat, datamatrix, nendog: number of endogenous variables,
% nlag:  number of lags; delay:  lead, usually zero
% output: yrs,xxxx,betax, tbetax tcritv ssr,rsq 
% crsq dw  fstat1, critv, infoc (aif,sif, hqif)
[tr nvar] = size(datmat);
nvar1 = nvar - nendog;
lag1 = nlag + 1;
yrhat = datmat(:,1:nendog); zz = datmat(:,nendog+1:nvar);
cr = nendog; cc = cr;
yrx = yrhat(lag1:tr,:);
yrx = yrx(1+delay:end,:);
j = 1:cr:(cr*lag1);
xxxx =  zeros(tr-nlag, nlag * cr);
for i = 1:nlag,
xxxx(:,j(i):j(i+1)-1) = yrhat(lag1-i:tr-i,:);
end 
xxxxz = [xxxx zz(nlag+1:tr,:)];
xxxxz = xxxxz(1:end-delay,:);
betaxx = (xxxxz'*xxxxz)\xxxxz'*yrx;
nnarg = nlag * cc;
lll = 0;
for jjj = 1:cc,
for iii = jjj:cc:nnarg,
lll = lll + 1;
xxxxx(:,lll) = xxxx(:,iii); end
end
nnarg = nlag* cc ;
xxxx = [xxxxx ];
xxxx = [xxxx zz(nlag+1:tr,:)];
xxxx = xxxx(1:end-delay,:);
[nrow ncol] = size(xxxx);
dgf = nrow - ncol;
% Full period estimation
YCORR = corrcoef(yrx);
for jjj = 1:cr,
betax(:,jjj) = (xxxx'*xxxx)\xxxx'*yrx(:,jjj);
yhatxx(:,jjj) = xxxx * betax(:,jjj);
ehatx(:,jjj) = yrx(:,jjj) - xxxx*betax(:,jjj);
rsq(:,jjj) =  var(yhatxx(:,jjj))/var(yrx(:,jjj));
sigy(:,jjj) = (yrx(:,jjj)'*yrx(:,jjj)) ./ (tr-1);
ssr(:,jjj) = ehatx(:,jjj)' * ehatx(:,jjj);
sigx(:,jjj) = ehatx(:,jjj)'*ehatx(:,jjj) ./ dgf;
crsq (:,jjj) = 1 - (1 - rsq(:,jjj)) * (tr-1)/dgf;
sigbx(:,jjj) = sigx(:,jjj).* diag(inv(xxxx'*xxxx));
tbetax(:,jjj) = betax(:,jjj) ./ sqrt(sigbx(:,jjj));
dehatx = diff(ehatx);
dw(:,jjj) = sum(dehatx(:,jjj) .^2) ./ ssr(:,jjj);
lik(:,jjj) = (1/2*pi*sigx(:,jjj))^.5 * exp(-.5*ehatx(:,jjj)'*ehatx(:,jjj) / sigx(:,jjj));
aif(:,jjj) = nrow * log(ssr(:,jjj)) + 2 * ncol ;
bif(:,jjj) = nrow * log(ssr(:,jjj)) + ncol * log(nrow) ;
hqif(:,jjj) = nrow * log(ssr(:,jjj)) + ncol * log(log(nrow));
end
infoc = [aif; bif; hqif];
tcritv = tcdf(abs(tbetax), dgf);
tcritv = ones(rows(tcritv),cols(tcritv)) - tcritv;
tcritv = 2 * tcritv;
% Calculation of Joint Zero Restriction and F-Statistics
for j = 1:nendog+1, 
if j ==1, xxxxr = trimc(xxxx, nlag, 0);
elseif 2 <= j <= nendog, xxxxr = keepc(xxxx, (j-1)*nlag, ncol-j*nlag); 
else xxxxr = xxxx(:,1:nendog*nlag); end
betar = (xxxxr'*xxxxr)\xxxxr'*yrx; 
sigr(j,:) = var(yrx - xxxxr * betar);
end
for lll = 1:nendog+1,
rrsq(lll,:) = ones(1,cr) - sigr(lll,:) ./ var(yrx);
fstat1(lll,:) = ((rsq(:,:) - rrsq(lll,:)) ./nlag) ./ ...
               ((ones(1,cr) - rsq(:,:)) ./ dgf);
end
for i = 1:nendog+1, for j=1:nendog, crit(i,j) = fcdf(fstat1(i,j),nlag,dgf); end; end
critv = ones(nendog+1,nendog) - crit;
% Impulse-response function for the Estimated Model
betaxx = betaxx(1:nlag*cr,:);
nnargs = nlag*cr;

% ASTAR = [betaxx(1:nnargs,:)'; eye(cr) zeros(cr,nnargs-1 * cr); ...
% zeros(cr,cr) eye(cr) zeros(cr,nnargs-2*cr); zeros(cr,2*cr) eye(cr) zeros(cr,nnargs-3*cr)
% zeros(cr,3*cr) eye(cr) zeros(cr,cr)];
% ASTAR = zeros(nnargs, nnargs);
% ASTAR(1:cr,1:nnargs) = betaxx(1:nnargs,:)';
% clear j;
% j = 1: cr : (cr*lag1);
% for i = 2: nlag,
% ASTAR(j(i):j(i+1)-1,j(i-1):j(i)-1) = eye(cr); end
% BSTAR = [eye(cr); zeros(nnargs-cr,cr)]; 
% CSTAR = eye(nnargs); DSTAR = zeros(nnargs,cr);
% for j = 1:nendog,
% ystar = dimpulse(ASTAR,BSTAR,CSTAR,DSTAR,j,10);
% ystar1 = ystar(:,1:nendog);
% ystarx = reshape(ystar1, 1, rows(ystar1)*cols(ystar1));
% ystarxx(j,:) = ystarx;
% end
% end