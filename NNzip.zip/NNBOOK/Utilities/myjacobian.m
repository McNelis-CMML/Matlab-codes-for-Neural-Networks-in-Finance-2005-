function jac = myjacobian(fun, beta, lambda);
% computes the jacobian matrix from the function;
% inputs: function, beta, lambda
% output: jacobian
[rr k] = size(beta);
value0 = feval(fun,beta);
vec1 = zeros(1,k);
for i = 1:k,
   vec2 = vec1;
   vec2(i) = max(lambda, lambda *beta(i));
   betax = beta + vec2;
   value1 = feval(fun,betax);
   jac(i) = (value1 - value0) ./ lambda;
   end
