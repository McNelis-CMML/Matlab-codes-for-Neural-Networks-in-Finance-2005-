function l=rows(x);
% ROWS 
% ROWS(X) returns the number of lines in matrix
i=size(x);
l=i(1,1);
