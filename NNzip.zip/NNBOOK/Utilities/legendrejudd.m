function llxx = legendrejudd(x, degree);
[rx, cx] = size(x);
llxx(:,1) = ones(rx,1);
llxx(:,2) = 1- x;
for i = 3:degree,
    ii = i-1;
    counter1 = (2*ii +1)/(ii+1);
    counter2 = ii/(ii+1);
    llxx(:,i) = counter1 .* x .* llxx(:,i-1) - counter2 .* llxx(:,i-2);
end
llxx = llxx(:,2:end);