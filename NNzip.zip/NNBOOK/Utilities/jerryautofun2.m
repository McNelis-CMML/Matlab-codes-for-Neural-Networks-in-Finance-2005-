function [error, yhat, pderiv,neuron3] = jerryautofun2(beta);
global data1 squasher maxx minx maxy miny malags;
y = data1(:,1);
x = data1(:,2:end);

[nx, cx] = size(x);

if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
ny = length(yy);
yhat1 = yy; 
xx1 = xx * beta(1:cx)' + ones(ny,1) * beta(2*cx+1);
xx2 = xx * beta(cx+1:2*cx)' + ones(ny,1) * beta(2*cx+2);
neuron1 = xx1;
neuron2 = xx2;
ehat(1:malags,1) = zeros(malags,1); 
neuron3(1:malags,1) = .5 * ones(malags,1); 
for i = malags+1:ny, 
neuron3(i,:) =  1 ./ (1 + exp(-beta(2*cx+3)* xx(i,end-2)));
EXX = ehat(i-malags:i-1,:);
yhat1(i,:) = neuron3(i,:) * neuron1(i,:) + (1- neuron3(i,:)) *   neuron2(i,:) + beta(2*cx + 4:2*cx+malags+3) * EXX;
ehat(i,:) = yy(i,:) - yhat1(i,:);
end;
nparm = 2 * cx + malags+3;
error = yy - yhat1;
error = mean(error .^2);
% sigma = error/ nparm;  
% T = length(yhat1);          
% loglik = -.5 * T * log(2 * pi) - .5 * T * log(sigma) - .5 * error /sigma;

% error = -loglik;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
for i = 1:cx,
for j = 2:ny,
    pderiv(j,i) =  neuron3(j,1) * beta(i) + (1-neuron3(j,1))  * beta(cx+i); 
end;
end;
    




