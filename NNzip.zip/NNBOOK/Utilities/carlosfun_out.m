function [error, yhat, pderiv,neuron3] = carlosfun_out(beta);
global data1 squasher maxx minx maxy miny;
y = data1(:,1);
x = data1(:,2:end);

[nx, cx] = size(x);

if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
ny = length(yy);


    neuron3 =  1 ./(1+ exp(-beta(2*cx+3) * xx(:,end-2)));
    xx11 =  xx* beta(1:cx)' + beta(2*cx+1);
    xx21=  xx * beta(cx+1:2*cx)' + beta(2*cx+2); 
    neuron1 = 1 ./ (1+ exp(-xx11));
    neuron2 = 1 ./ (1+ exp(-xx21));
    yhat1 =  neuron3 * neuron1 + (1-neuron3) * neuron2; 
   
end


if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
nparm = 2 * cx + 27;
lik = yhat .^ y .* (1-yhat) .* (1-y);
loglik = sum(log(lik));
error = -loglik;
for i = 1:cx,
    pderiv(:,i) =  neuron3 .* neuron1 .* (1-neuron1) * beta(i) + (1-neuron3) .*  neuron2 .* (1-neuron2) * beta(cx+i); 
end;







