function [error, yhat, Jstat, Jsig, neuron1, V, SIGB] = cm_mod4_gmm(beta);
global squasher data1 minx miny maxx maxy malags nwlags instlags z nwestdum 
global neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol LAMBDA arlags;
% beta = abs(beta);
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x(:,1:2+arlags));
[nxx, cxx] = size(x);
ny = length(y);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cxx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
% z = mylag(x(:,[arlags 2+arlags+1:2+arlags+2]), instlags);
yy = y(instlags+1:end,:);,
xx = x(instlags+1:end,:);
[nxxx, cxxx] = size(xx);
if squasher == 1,
    cxarg_yvol = (cthres_yvol-minx(neuronxarg_yvol)) / (maxx(neuronxarg_yvol)-minx(neuronxarg_yvol));
else cxarg_yvol = cthres_yvol;
end
if squasher == 1,
    cxarg_ygap = (cthres_ygap-minx(neuronxarg_ygap)) / (maxx(neuronxarg_ygap)-minx(neuronxarg_ygap));
    cxarg_inf = (cthres_inf-minx(neuronxarg_inf)) / (maxx(neuronxarg_inf)-minx(neuronxarg_inf));
else cxarg_ygap = cthres_ygap; cxarg_inf = cthres_inf;
end
neuron1x = abs(beta(cx+2)) .* (xx(:,neuronxarg_yvol)-cxarg_yvol);
neuron1 =   (2 ./ (1 + exp(-2 * neuron1x))-1);
yhat1 =  xx(:,1:cx) * abs(beta(1:cx))' + ones(nxxx,1) * (beta(cx+1)) + neuron1 .* abs(beta(neuronxarg_ygap)) .* xx(:,neuronxarg_ygap);

nparm =  cx + 2;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat = y(instlags+1:end,:) - yhat;
[nz, cz] = size(z);
mm = z' * ehat / ny;
mhat = mm(:);
mm1 = repmat(ehat,1, cz) .* z;
S = diag(diag(cov(mm1)));
[LS, CS] = size(S);
if nwestdum == 0,
vm = S\eye(CS);
else vm = neweywest(mm1, nwlags); vm = vm\eye(CS);
end
error = mm' * vm * mm;
Jstat = error * ny;
dgf = cz - length(beta);
Jsig = 1 - chi2cdf(Jstat, dgf);
xxn = (ones(length(xx),1) - neuron1 .* neuron1);
% xxn2 = ones(length(x),1) - neuron2 .* neuron2;
% xxn3 = ones(length(x),1) - neuron3 .* neuron3;
% xxx = [xx(:,1), xx(:,2) + xx(:,2) .* neuron2, xx(:,2) + xx(:,2) .* neuron3,  ones(length(x),1),...
%     xxn .*beta(3) .*  xx(:,3).* (xx(:,neuronxarg_yvol)-cxarg_yvol), beta(2) .* xxn2 .* xx(:,2) .* (xx(:,2)-cxarg_inf),...
%     beta(3) .* xxn3 .* xx(:,3) .* (xx(:,3)-cxarg_ygap)];
 xxx = [xx(:,1:cx),  ones(length(xx),1),...
     xxn .*beta(neuronxarg_ygap) .*  xx(:,neuronxarg_ygap).* (xx(:,neuronxarg_yvol)-cxarg_yvol)];

M = kron(eye(1),-z'*xxx/length(xxx));
V1 = inv(M' * vm * M);
V = V1 ./ nz;
SIGB = real(sqrt(diag(V)))';
[ns, cs] = size(SIGB);
for j = 1:cs, 
    if SIGB(j) == 0, 
    SIGB(j) = .001; 
    end
end







