function [loglik, yhat, neuron1, neuron2] = cm_mod3_mlik(beta);
global squasher data1 minx miny maxx maxy malags nwlags neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol LAMBDA CMDUM;
% beta(1) = 1 / (1+exp(-beta(1)));

y = data1(:,1);
x = data1(:,2:end-1);
[nx, cx] = size(x);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg_ygap = (cthres_ygap-minx(neuronxarg_ygap)) / (maxx(neuronxarg_ygap)-minx(neuronxarg_ygap));
    cxarg_inf = (cthres_inf-minx(neuronxarg_inf)) / (maxx(neuronxarg_inf)-minx(neuronxarg_inf));
else cxarg_ygap = cthres_ygap; cxarg_inf = cthres_inf;
end
ny = length(yy);
xx1 = xx * abs(beta(1:cx))' + ones(ny,1) * ((beta(cx+1)));
if CMDUM == 0, 
neuronx1 = abs(beta(cx+2))*(xx(:,neuronxarg_inf)-cxarg_inf);
neuronx2 = abs(beta(cx+3))* (xx(:,neuronxarg_ygap)-cxarg_ygap);
else neuronx1 = LAMBDA *(xx(:,neuronxarg_inf)-cxarg_inf);
neuronx2 = LAMBDA * (xx(:,neuronxarg_ygap)-cxarg_ygap);
end;
neuron1 =  2 ./ (1 + exp(-2 * neuronx1))-1;
neuron2 =  2 ./ (1 + exp(-2 * neuronx2))-1;
if CMDUM == 0,
yhat1 = xx1  + ...
    neuron1 .* abs(beta(neuronxarg_inf)) .* xx(:,neuronxarg_inf) -...
    neuron2 .* abs(beta(neuronxarg_ygap)) .* xx(:,neuronxarg_ygap) ;
else yhat1 = xx1  + ...
    neuron1 .* abs(beta(cx+2)) .* xx(:,neuronxarg_inf) -...
    neuron2 .* abs(beta(cx+3)) .* xx(:,neuronxarg_ygap) ;
end;
if malags > 0, 
ehat1 = zeros(malags,1);
for i = malags+1:ny, 
EXX = ehat1(i-malags:i-1,:);
yhat1(i,:) = yhat1(i,:)+ beta(cx + 4: end) * EXX;
ehat1(i,:) = yy(i,:) - yhat1(i,:);
end
end
nparm =  cx + 3 + malags;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat = y - yhat;
nparm = cx + malags + 1;
error = ehat;  
errorsq = (error .^2);
T = length(yhat); 
sigmavar = sum(errorsq)/ (T-nparm);  
sigmastd = sqrt(sigmavar);
errornorm = error ./ sigmastd;
loglik1 = -.5 * T * log(2 * pi) - .5 * T * log(sigmavar) - .5 *  sum((errornorm).^2) ;
loglik = -loglik1;






