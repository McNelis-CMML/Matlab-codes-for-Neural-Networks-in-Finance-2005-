function [sse3,g,A3,W3,b3,W4,b4,W5,b5,W6,b6] = emnetg1x(beta);
global P T nlayer nneuron1 nneuron2 nneuron3;
[rp cp] = size(P);
W5 = 0; b5 = 0; W6 = 0; b6 = 0;
if nlayer == 1, 
beta1 = beta(1:nneuron1*rp);
W3 = reshape(beta1,nneuron1,rp);
b3 = beta(nneuron1*rp+1:nneuron1*rp+nneuron1);
W4 = beta(nneuron1*rp+nneuron1+1:nneuron1*rp+2*nneuron1);
b4 = beta(end);
% A3 = simuff(P,W3,b3,'logsig',W4,b4,'purelin');
A3  =  feval('logsig', W3 * P, b3');
A3  = feval('purelin', W4 * A3, b4);
elseif nlayer == 2,
beta1 = beta(1:nneuron1*rp);
W3 = reshape(beta1,nneuron1,rp);
b3 = beta(nneuron1*rp+1:nneuron1*rp+nneuron1);
beta2 = beta(nneuron1*rp+nneuron1+1:nneuron1*rp+nneuron1+nneuron1*nneuron2);
W4 = reshape(beta2, nneuron2, nneuron1);
b4 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2);
W5 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2);
b5 = beta(end);
% A3 = simuff(P,W3, b3, 'logsig', W4, b4, 'logsig', W5, b5, 'purelin');
A3 = feval('logsig', W3 * P, b3');
A3 = feval('logsig', W4 * A3, b4');
A3 = feval('purelin', W5 * A3, b5);
else
beta1 = beta(1:nneuron1*rp);
W3 = reshape(beta1,nneuron1,rp);
b3 = beta(nneuron1*rp+1:nneuron1*rp+nneuron1);
beta2 = beta(nneuron1*rp+nneuron1+1:nneuron1*rp+nneuron1+nneuron1*nneuron2);
W4 = reshape(beta2, nneuron2, nneuron1);
b4 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2);
beta3 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2* nneuron3);
W5 = reshape(beta3, nneuron3, nneuron2);
b5 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2* nneuron3+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2* nneuron3+nneuron3);
W6 = beta(nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2* nneuron3+nneuron3+1:nneuron1*rp+nneuron1+nneuron1*nneuron2+nneuron2+ nneuron2* nneuron3+ 2* nneuron3);
b6 = beta(end);
% A3 = simuff(P,W3, b3, 'logsig', W4, b4, 'logsig', W5, b5, 'purelin');
A3 = feval('logsig', W3 * P, b3');
A3 = feval('logsig', W4 * A3, b4');
A3 = feval('logsig', W5 * A3, b5');
A3 = feval('purelin', W6 * A3, b6);
end
err3 = T-A3;
sse3 = sumsqr(err3);
ssrsq3 = var(A3) / var(T);
g = [];


