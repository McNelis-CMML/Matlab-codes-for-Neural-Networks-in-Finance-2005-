 function [qstat, msig, autorho] = qstatlb(zz, p,k);
%  Leung-Box Q Statistic for Regression Residual
%  Input:  zz data, p: order of lags, k: number of regressors
%  Output:  qstat, msig, autocorrelations
zzlag = mylag(zz, p);
zzz = [zz(p+1:end,:) zzlag];
junk = cov(zzz);
zzz = zz(p+1,end,:);
zzsq = zzz .^ 2;
sumzzsq = sum(zzsq);
autorho = junk(1,2:p+1) ./ junk(1,1);
rhosq = autorho .^2;
[tt,cc] = size(zz);
for j = 1:p, ttjj(j) = tt - j; end;
rhosqj = rhosq ./ ttjj;
qstat = tt * (tt+2) * sum(rhosqj);
msig = 1 - chi2cdf(qstat, p - k);

