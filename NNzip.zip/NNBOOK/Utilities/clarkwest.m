function [WESTSTAT, WESTPVALUE] = clarkwest(error1, error2, yhat2, tau);
%  Clark and West Test for Predictive Accuracy with Nested Models
%  Inputs, error1, error2:  out of sample errors for smaller and larger
%  model,  yhat2:  predicted y for larger model
%  outputs:  weststat, westpvalue
%  lags for correction of variance/covariance matrix

WESTP = length(error1);
fhat = error1 .^2 - (error2.^2 - yhat2.^2);
fbar = mean(fhat);
if tau == 0,
WESTV = var(fhat,1);
else   WESTV = neweywest1(fhat, tau);
end
WESTSTAT = sqrt(WESTP) * fbar;
WESTPVALUE = 1 - normcdf(WESTSTAT, 0, sqrt(WESTV));

