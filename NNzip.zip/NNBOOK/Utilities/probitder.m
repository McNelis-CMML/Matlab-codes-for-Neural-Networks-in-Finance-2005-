function pderivpb = probitder(pbar, beta);
% pderivpb = probitder(beta);
% partial derivative of input arguments for probit function
yy = normpdf(beta(1:end-1) * pbar + beta(end));
pderivpb = yy .* beta(1:end-1);