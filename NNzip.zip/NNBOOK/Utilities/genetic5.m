function [controlb, sumutilb, repl] = genetic5(fun,nparm,popsize, maxgen, pc, pmstart, elite,pdes,maxgen1,toler,scale, beta0);
% Inputs: fun, nparm, popsize, maxgen, pc, pmstart, elite, 
% pdes, maxgen1,toler,scale, beta0
fun1 = 'tansig';
pmend = .025;
pshuffle = .33;
plinear = .33;
b = 2;
global nrun;
sseb = 10000;
for repl = 1:maxgen,
if repl ==1,  www = [ beta0; (randn(popsize-1,nparm))] .* scale;
% disp('Now finding initial fitness values')
for i = 1:popsize,
sse100(i) =  feval(fun,www(i,:));
end
else www = nwww; sse100 = nsse1; end
if rand(1,1) < pdes, www = [www(1,:); (randn(popsize-1,nparm))]; else www = www; end;
% disp('Now doing genetic operators')
for ii = 1:2:popsize,
for j = 1:4,
if repl == 1, ind = 1; end
if ii ==1 & j==1, nnrow(j) = ind; else nnrow(j) = round(rand * (popsize-1)) + 1; end
end
if sse100(nnrow(1)) < sse100(nnrow(2)), p1 = nnrow(1); else p1 = nnrow(2); end
if sse100(nnrow(3)) < sse100(nnrow(4)), p2 = nnrow(3); else p2 = nnrow(4); end
if rand(1,1) <= pc,
  
   randy = rand(1,1);
   if randy < pshuffle,
      for jj=1:nparm, if rand(1,1) < .5,
            child1(1,jj) =www(p1,jj); child2(1,jj) = www(p2,jj); 
         else child1(1,jj) =www(p2,jj); child2(1,jj) = www(p1,jj); end
      end
   elseif randy < (pshuffle + plinear),
      aaa = rand(1,1);
      for jj = 1:nparm,
         child1(1,jj) = aaa * www(p1,jj) + (1-aaa) * www(p2,jj);
         child2(1,jj) = aaa * www(p2,jj) + (1-aaa) * www(p1,jj);
      end
   else          
            cutpoint = (round(rand(1,1)) * (nparm-2))+1; 
            child1 = [www(p1,1:cutpoint) www(p2, cutpoint+1:nparm)];
            child2 = [www(p2,1:cutpoint) www(p1, cutpoint+1:nparm)]; 
         end
         
else child1 = www(p1, 1:nparm); child2 = www(p2, 1:nparm); end
for jj = 1: nparm, 
   pm = pmend + (pmstart - pmend) / repl;
   rmax = repl / maxgen1;
if rand(1,1) <= pm, child1(jj) = child1(jj) + randn(1,1)* (1- (rand(1,1)^((1-rmax)* b))); else child1(jj) = child1(jj); end
if rand(1,1) <= pm, child2(jj) = child2(jj) + randn(1,1)* (1- (rand(1,1)^((1-rmax)* b))); else child2(jj) = child2(jj); end
end
ssechild1 = feval(fun,child1);
ssechild2 = feval(fun,child2);
wwwc = [www(p1,:); www(p2,:); child1; child2];
ssec = [sse100(p1); sse100(p2); ssechild1; ssechild2];
[ssez, indc] = sort(ssec);
if elite == 1, nwww(ii,:) = wwwc(indc(1),:); else nwww(ii,:) = wwwc(3,:); end
if elite == 1, nwww(ii+1,:) = wwwc(indc(2),:); else nwww(ii+1,:) = wwwc(4,:); end
if elite == 1, nsse(ii) = ssec(indc(1)); else nsse(ii) = ssec(3); end
if elite == 1, nsse(ii+1) = ssec(indc(2)); else nsse(ii+1) = ssec(4); end
end
% disp('Min sse, index of population');
% for kk = 1:popsize, nsse1(kk) = feval(fun, nwww(kk,:)); end;
nsse1 = nsse;
[sseb, ind] = min(nsse1);
ssemean = mean(nsse1);
ssebind(repl) = sseb;
bestwww = nwww(ind,:);
sseb1 = feval(fun, bestwww);
[repl sseb ind ssemean];
end


while abs(ssebind(repl)- ssebind(repl-(maxgen-1))) > toler & repl < maxgen1, 
% while ssebind(repl) > toler & repl < maxgen1, 
  
repl = repl + 1;
www = nwww; sse100 = nsse1;
if rand(1,1) < pdes, www = [www(1,:); tansig(randn(popsize-1,nparm))]; else www = www; end;
% disp('Now doing genetic operators')
for ii = 1:2:popsize,
for j = 1:4,
if repl == 1, ind = 1; end
if ii ==1 & j==1, nnrow(j) = ind; else nnrow(j) = round(rand * (popsize-1)) + 1; end
end
if sse100(nnrow(1)) < sse100(nnrow(2)), p1 = nnrow(1); else p1 = nnrow(2); end
if sse100(nnrow(3)) < sse100(nnrow(4)), p2 = nnrow(3); else p2 = nnrow(4); end

if rand(1,1) <= pc,
   randy = rand(1,1);
   if randy < pshuffle,
      for jj=1:nparm, if rand(1,1) < .5,
            child1(1,jj) =www(p1,jj); child2(1,jj) = www(p2,jj); 
         else child1(1,jj) =www(p2,jj); child2(1,jj) = www(p1,jj); end
      end
   elseif randy < (pshuffle + plinear),
      aaa = rand(1,1);
      for jj = 1:nparm,
         child1(1,jj) = aaa * www(p1,jj) + (1-aaa) * www(p2,jj);
         child2(1,jj) = aaa * www(p2,jj) + (1-aaa) * www(p1,jj);
      end
   else          
            cutpoint = (round(rand(1,1)) * (nparm-2))+1; 
            child1 = [www(p1,1:cutpoint) www(p2, cutpoint+1:nparm)];
            child2 = [www(p2,1:cutpoint) www(p1, cutpoint+1:nparm)]; 
         end
         
else child1 = www(p1, 1:nparm); child2 = www(p2, 1:nparm); end





for jj = 1: nparm,
   pm = pmend + (pmstart - pmend) / repl;
rmax = repl / maxgen1;
if rand(1,1) <= pm, child1(jj) = child1(jj) + randn(1,1)* (1- (rand(1,1)^((1-rmax)* b))); else child1(jj) = child1(jj); end
if rand(1,1) <= pm, child2(jj) = child2(jj) + randn(1,1)* (1- (rand(1,1)^((1-rmax)* b))); else child2(jj) = child2(jj); end
   
end
ssechild1 = feval(fun,child1);
ssechild2 = feval(fun,child2);
wwwc = [www(p1,:); www(p2,:); child1; child2];
ssec = [sse100(p1); sse100(p2); ssechild1; ssechild2];
[ssez, indc] = sort(ssec);
if elite == 1, nwww(ii,:) = wwwc(indc(1),:); else nwww(ii,:) = wwwc(3,:); end
if elite == 1, nwww(ii+1,:) = wwwc(indc(2),:); else nwww(ii+1,:) = wwwc(4,:); end
if elite == 1, nsse(ii) = ssec(indc(1)); else nsse(ii) = ssec(3); end
if elite == 1, nsse(ii+1) = ssec(indc(2)); else nsse(ii+1) = ssec(4); end
end
% for kk = 1:popsize, nsse1(kk) = feval(fun, nwww(kk,:)); end;
nsse1 = nsse;
[sseb, ind] = min(nsse1);
ssemean = mean(nsse1);
ssebind(repl) = sseb;
bestwww = nwww(ind,:);
sseb1 = feval(fun, bestwww);
[repl sseb ind ssemean];
end
controlb = bestwww;
sumutilb = ssebind(repl);
