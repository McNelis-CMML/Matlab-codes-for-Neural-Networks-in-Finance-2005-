function [error, yhat, pderiv,neuron3] = jerryauto(beta);
global data1 squasher maxx minx maxy miny malags;
y = data1(:,1);
x = data1(:,2:end);

[nx, cx] = size(x);

if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
ny = length(yy);
yhat1 = yy; 
xx0 = xx * beta(1:cx)';
neuron1 = 1 ./ (1 + exp(-xx * beta(cx+1:2*cx)'));
neuron2 = 1 ./ (1 + exp(-xx * beta(2*cx+1:3* cx)'));
ehat(1:malags,1) = zeros(malags,1); 
neuron3(1:malags,1) = .5 * ones(malags,1); 
for i = malags+1:ny, 
neuron3(i,:) =  1 ./ (1 + exp(-beta(end)* xx(i,end-2)));
EXX = ehat(i-malags:i-1,:);
yhat1(i,:) = beta(3*cx+1) + xx0(i,:) + neuron3(i,:) * neuron1(i,:) + (1- neuron3(i,:)) *   neuron2(i,:) + beta(3*cx + 2: 3*cx+malags+1) * EXX;
ehat(i,:) = yy(i,:) - yhat1(i,:);
end;

nparm = 3 * cx + malags + 2;
error = yy - yhat1;
error = mean(error .^2);
% sigma = error/ nparm;  
% T = length(yhat1);          
% loglik = -.5 * T * log(2 * pi) - .5 * T * log(sigma) - .5 * error /sigma;
% 
% error = -loglik;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
for i = 1:cx,
for j = 2:ny,
    pderiv(j,i) = beta(i) + neuron3(j,1) .* neuron1(j,1) .* (1-neuron1(j,1)) * beta(cx+i) + (1-neuron3(j,1)) .*  neuron2(j,1) .* (1-neuron2(j,1)) * beta(2*cx+i); 
end;
end;
    




