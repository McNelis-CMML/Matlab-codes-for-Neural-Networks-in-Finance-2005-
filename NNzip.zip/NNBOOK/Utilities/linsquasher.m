function yy = linsquasher(xx);
minx = min(xx);
maxx = max(xx);
[rrx, ccx] = size(xx);
for j = 1:ccx,
    yy(:,j) =  (xx(:,j) - ones(rrx,1) .* minx(j)) / (maxx(j)-minx(j));
end