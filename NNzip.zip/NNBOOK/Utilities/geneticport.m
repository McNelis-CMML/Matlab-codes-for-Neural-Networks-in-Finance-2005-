function [controlb, sumutilb, repl] = geneticport(fun,nparm,pc, pmend, pmstart,elite,toler,beta);
% function [controlb, sumutilb] = genetic1(fun,nparm,popsize, maxgen, pc, pm, elite,maxgen1,toler);
global nrun;
popsize = 10 * nparm;
maxgen = 3 * nparm;
maxgen1 =  maxgen + 2 * nparm;
controls = randn(1,nparm);
scale = 1;
sseb = 10000;
for repl = 1:maxgen,
   if repl ==1,  www = abs([beta; randn(popsize-1,nparm)]);
      for i = 1:popsize, for j = 1:nparm, www(i,j) = www(i,j)/ sum(www(i,1:nparm));
            end; end
      
      % disp('Now finding initial fitness values')
      for i = 1:popsize,
sse100(i) =  feval(fun,www(i,:));
end
else www = nwww; sse100 = nsse; end
% disp('Now doing genetic operators')
for ii = 1:2:popsize,
for j = 1:4,
if repl == 1, ind = 1; end
if ii ==1 & j==1, nnrow(j) = ind; else nnrow(j) = round(rand * (popsize-1)) + 1; end
end
if sse100(nnrow(1)) < sse100(nnrow(2)), p1 = nnrow(1); else p1 = nnrow(2); end
if sse100(nnrow(3)) < sse100(nnrow(4)), p2 = nnrow(3); else p2 = nnrow(4); end
if rand(1,1) <= pc, cutpoint = (round(rand(1,1)) * (nparm-2))+1; 
child1 = [www(p1,1:cutpoint) www(p2, cutpoint+1:nparm)];
child2 = [www(p2,1:cutpoint) www(p1, cutpoint+1:nparm)]; 
else child1 = www(p1, 1:nparm); child2 = www(p2, 1:nparm); end
for jj = 1: nparm, 
   pm = pmend + (pmstart - pmend)/repl;
if rand(1,1) <= pm, child1(jj) = child1(jj) + randn(1,1) ; else child1(jj) = child1(jj); end
if rand(1,1) <= pm, child2(jj) = child2(jj) + randn(1,1) * scale;; else child2(jj) = child2(jj); end
end
ssechild1 = feval(fun,child1);
ssechild2 = feval(fun,child2);
wwwc = [www(p1,:); www(p2,:); child1; child2];
ssec = [sse100(p1); sse100(p2); ssechild1; ssechild2];
[ssez, indc] = sort(ssec);
if elite == 1, nwww(ii,:) = wwwc(indc(1),:); else nwww(ii,:) = wwwc(3,:); end
if elite == 1, nwww(ii+1,:) = wwwc(indc(2),:); else nwww(ii+1,:) = wwwc(4,:); end
if elite == 1, nsse(ii) = ssez(indc(1)); else nsse(ii) = ssec(3); end
if elite == 1, nsse(ii+1) = ssez(indc(2)); else nsse(ii+1) = ssec(4); end
end
% disp('Min sse, index of population');
[sseb, ind] = min(nsse);
[repl sseb ind]
ssebind(repl) = sseb;
end


while ssebind(repl)- ssebind(repl-(maxgen-5)) > toler & repl < maxgen1, 
   repl = repl + 1
   www = nwww; sse100 = nsse;
% disp('Now doing genetic operators')
for ii = 1:2:popsize,
for j = 1:4,
if repl == 1, ind = 1; end
if ii ==1 & j==1, nnrow(j) = ind; else nnrow(j) = round(rand * (popsize-1)) + 1; end
end
if sse100(nnrow(1)) < sse100(nnrow(2)), p1 = nnrow(1); else p1 = nnrow(2); end
if sse100(nnrow(3)) < sse100(nnrow(4)), p2 = nnrow(3); else p2 = nnrow(4); end
if rand(1,1) <= pc, cutpoint = (round(rand(1,1)) * (nparm-2))+1;
child1 = [www(p1,1:cutpoint) www(p2, cutpoint+1:nparm)];
child2 = [www(p2,1:cutpoint) www(p1, cutpoint+1:nparm)]; 
else child1 = www(p1, 1:nparm); child2 = www(p2, 1:nparm); end
for jj = 1: nparm, 
   pm = pmend + (pmstart - pmend)/repl;
if rand(1,1) <= pm, child1(jj) = child1(jj) + randn(1,1) ; else child1(jj) = child1(jj); end
if rand(1,1) <= pm, child2(jj) = child2(jj) + randn(1,1) * scale;; else child2(jj) = child2(jj); end
end
ssechild1 = feval(fun,child1);
ssechild2 = feval(fun,child2);
wwwc = [www(p1,:); www(p2,:); child1; child2];
ssec = [sse100(p1); sse100(p2); ssechild1; ssechild2];
[ssez, indc] = sort(ssec);
if elite == 1, nwww(ii,:) = wwwc(indc(1),:); else nwww(ii,:) = wwwc(3,:); end
if elite == 1, nwww(ii+1,:) = wwwc(indc(2),:); else nwww(ii+1,:) = wwwc(4,:); end
if elite == 1, nsse(ii) = ssec(indc(1)); else nsse(ii) = ssec(3); end
if elite == 1, nsse(ii+1) = ssec(indc(2)); else nsse(ii+1) = ssec(4); end
end
[sseb, ind] = min(nsse);
ssebind(repl) = sseb;
[repl sseb ind]
end
controlb = www(ind,:);
sumutilb = ssebind(repl);
