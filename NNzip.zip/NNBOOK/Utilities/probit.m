function [LIK, ssr, yhat, pderiv] = probit(beta);
global P T;
[rr cc] = size(T);
[rx, cx] = size(P);
y = T; x = P;
beta1 = beta;
nn =  P * beta1(1:end-1)' + ones(length(P),1) * beta1(end);
yhat = normcdf(nn);
yhat1 = normcdf(-nn);
ssr = (T - y)' * (T-y);
y = T;
lik =  y .* log(yhat) + (1-y) .* log(yhat1);
LIK = -sum(lik);
xmean = mean(x);
yhatmean = xmean * beta1(1:end-1)' + beta(end);
yhatmean = normcdf(yhatmean);
for i= 1:cx,
pderiv(i) = mean(normpdf(yhat) .* beta1(i));
end
