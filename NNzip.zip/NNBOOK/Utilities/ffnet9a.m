function [ssebest,rsqbest,rmsqbest,hqifbest,pderbest,tstatn,yyyhat, yyyout,W1,w1best,w2best,w3best, w4best,...
      nrow1,yxmat, bols,b1best, b2best,b3best, b4best,foutput,exitflag, nparm] = ...
   ffnet8(assetx,target,percent,nlag,delay,info,gendum,maxgen, maxgen1, helge,derdum,delta);
% Ouputs:
%     output: 
%             sse, rsq, rmsq, hqif, pderiv ,tstatn, yyyhat, yyyout,Wols,W1net,W2net,W3net, W4net,
%             yyyhat, yyyout,  nrow1,
%			  yxmat bols,b1best,b2best,b3best,b4best
% Inputs:
%      Input matrix,
%      column of dep variable,  
%      percent of data for in sample,
%      number of lags
%		 delay factor (forecasting more than one period ahead
%      info:  no of  hidden layers, neurons in 1 , 2, 3, (3 max)
%      gendum:  
%          genetic algorithm with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%      maxgen:  number of generations for ga
%      nepoch:  number of epochs or iterations for function optimizer
%      dummy for squasher, 1 for helge, 2 for DeLeo, 3 for matlab linear, 0 for none
% 		 dummy for partial derivative, 0 for mean, 1 for endpoint
%      delta:  difference for evaluating partial derivatives

global nlayer nneuron1 nneuron2 nneuron3;
fun = 'ffnet9fun';
warning off;
nntwarn off;
if nargin == 8,
    helge = 3; maxgen1 = 5000; derdum = 1; delta = .000001;
end
nlayer = info(1);
nneuron1 = info(2);
nneuron2 = info(3);
nneuron3 = info(4);
popsize = 50; pc = .9; pdes = 0; toler = .001; elite = 1;
[rr cc] = size(assetx);
% nlag = 1;   % number of lags and arguments.
yrhat = [assetx];
if nlag == 0,
    y = assetx(1+delay:end,target); 
    x = assetx(:,target(end)+1:end,:); 
    x = x(1:end-delay,:);
    else [y x] = mylagvv(assetx, nlag, target, delay);
end;
yxmat = [y x];
   [nrow ncol] = size(x);
   [nrowy ncoly] = size(y);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = [ x(1:nrow1,:)];
[nrow ncol] = size(x);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = x(1:nrow1,:);
smin = .1;
smax = .9;
[rx, cx] = size(x);
[ry, cy] = size(y);
maxy = max(y);
miny = min(y);
maxx = max(x);
minx = min(x);
meany = mean(y);
sigy = std(y);
yz = detrend(y,0) ./ kron(ones(rx,1), sigy);
meanx = mean(x);
sigx = std(x);
xz = detrend(x,0) ./ kron(ones(rx,1),sigx);;
for i = 1:cy,
   ys(:,i) = hsquasher(y(:,i), smax, smin);
   yss(:,i) = 1 ./ (1+ exp(-(yz(:,i))));
end
for i = 1:cx,
   xs(:,i) = hsquasher(x(:,i), smax, smin);
   xss(:,i) = 1 ./(1+ exp(-(xz(:,i))));
end
if helge == 0, PN = x; TN = y; 
    elseif helge == 1, PN = xs; TN = ys;
    elseif helge == 2, PN = xss; TN = yss;
    else PP = x; TT = y;
    [rp, cp] = size(PP);
        for i = 1:cp, PN(:,i) = (PP(:,i)- minx(i)) ./ (maxx(i)-minx(i)); 
        end
        for i = 1:cy,
        TN(:,i) = (TT(:,i)-miny(i))/(maxy(i)-miny(i));
        end
end
global P T;
P = PN(1:nrow1,:);
T = TN(1:nrow1,:);
Praw = xx;
Traw = yy;
Praw1 = [Praw ones(length(Praw),1)];

betaols = inv(Praw1' * Praw1) * Praw1' * Traw;
A1 = Praw1 * betaols;
W1 = betaols(1:end-1);
err1 = Traw - A1; 
sse1 =  err1' * err1;
Als = A1;
yhatls = Als;
[yyr yyc] = size(yhatls);
err1 = yy - yhatls; 
ssrsq1 = ones(1,yyc) - var(err1) ./ var(yy);
hqols = nrow1 * log(sse1) + (ncol+1) * log(log(nrow1));
[rp,cp] = size(P);
if nlayer == 1, nparm = nneuron1*cp + nneuron1 + nneuron1 * ncoly + ncoly;
    elseif nlayer == 2, nparm = nneuron1 * cp + nneuron1 + nneuron1 * nneuron2 +  nneuron2 +  nneuron2 * ncoly + ncoly;
    else nparm = nneuron1 * cp + nneuron1 + nneuron1 * nneuron2 + nneuron2 + nneuron2 * nneuron3 +  nneuron3 + nneuron3 * ncoly + ncoly;
end
nepoch = maxgen1; scale = 1; beta0 = randn(1,nparm);
tp = [25, nepoch, .02, .01, 1.07, .7, .9, 1.04]; 
pm = .33; elite = 1; pdes = 0; 
if gendum >= 1, beta = ...
   gen7f(fun,beta0,popsize,maxgen);     
else beta = .01 * ones(1, nparm); 
end
[criterion,sse3,g,A3,W3,b3,W4,b4, W5, b5, W6, b6] = feval(fun,beta);
if gendum <= 1,
    options = optimset('MaxFunEvals', nepoch, 'MaxIter', nepoch,...
    'TolFun', delta);
    [beta,foutput,exitflag] = fminunc(fun, beta, options);
    tstatn = tstatapp(fun, beta, delta);
    [criterion,sse3,g,A3, W3,b3,W4,b4, W5, b5, W6, b6] = feval(fun,beta);
    else W3=W3; b3 = b3; W4 = W4; b4 = b4; W5 = W5, b5 = b5, W6 = W6, b6 = b6; 
end
if helge == 0, A3n = A3; 
    elseif helge == 1, A3 = A3;
        for i = 1:cy,
        A3x(:,i) = helgeyx(A3(:,i), maxy(i), miny(i),smax,smin);
        end
    A3 = A3;
    A3n = A3x; 
    elseif helge == 2, A3 = A3;
    A3x = -log(1./A3- ones(size(A3)));
    A3x = real(A3x); [junkr, junkc] = size(A3x);
    A3x = kron(ones(junkr,1),meany) + A3x .* kron(ones(junkr,1),sigy);
    A3 = A3;
    A3n = A3x; A3n = real(A3n);
    else 
        for i = 1:cy,
        A3n(:,i) = A3(:,i) * (maxy(:,i)-miny(:,i)) + miny(:,i);
        end
end
   
yhatnet = A3n;
ydep = yy;
yhat = [ydep yhatls yhatnet]; 
err3 = ydep - yhatnet;
sse3 = sum(err3 .^2);
hqnet = nrow1 .* log(sse3) + (nparm) * log(log(nrow1));
% ssrsq3 = var(yhatnet) ./ var(ydep);
ssrsq3 = ones(1,yyc) - var(err3) ./ var(yy);
sse = [sse1; sse3];
hqif = [hqols; hqnet];
ssrsq = [ssrsq1; ssrsq3];
xxmean = mean(xx);
xxend = xx(end,:);
if derdum == 0, 
    xstar = xxmean; 
    else xstar = xxend; 
end
if helge == 0, pstar = xstar;
    elseif helge == 1, 
        for i = 1:cx,
        pstar(1,i) = hsquasher(xstar(1,i), smax, smin, maxx(1,i), minx(1,i));
        end
    elseif helge == 2, pstar = (1 ./ 1+ exp(-((xstar - meanx)))./ sigx); 
    pstar = real(pstar);
    else 
        for i=1:cp,
            pstar(:,i) = (xstar(:,i) - minx(i)) ./ (maxx(i) - minx(i)); 
        end
end
pstar = pstar;
hdelta = delta;
[rp, cp] = size(P);
hdeltav = eye(cp) * hdelta;
if nlayer == 1,  
    A3star =  pstar * W3+ b3;
    A3star = 1./(1+exp(-A3star));
    A3star = A3star * W4 + b4;
elseif nlayer == 2,
    A3star = pstar * W3+ b3;
    A3star = 1./(1+exp(-A3star));
    A3star = A3star * W4 + b4;
    A3star = 1./(1+exp(-A3star));
    A3star = A3star * W5 + b5;
else
  A3star = pstar * W3+ b3;
  A3star = 1./(1+exp(-A3star));
  A3star = A3star * W4 + b4;
  A3star = 1./(1+exp(-A3star));
  A3star = A3star * W5 + b5;
  A3star = 1./(1+exp(-A3star));
  A3star = A3star * W6 + b6;
end
if helge == 0, A3star = A3star;
    elseif helge == 1, 
    A3star = A3star;
        for ii = 1:cy,
        A3star(:,ii) = helgeyx(A3star(:,ii),maxy(1,ii), miny(1,ii),smax, smin);
        end
    A3star = A3star;
    elseif helge == 2,
    A3star = A3star;
    A3star = -log(1./A3star - ones(size(A3star)));
    A3star = meany + A3star .* sigy;
    A3star = A3star;
    else  
        for i = 1:cy,
            A3star(:,i) = A3star(:,i) .* (maxy(i)-miny(i)) + miny(i);
        end
end


for i = 1:cp,
    
    
   [rxstar, cxstar] = size(xstar);
   xdel = xstar + kron(ones(rxstar,1),hdeltav(i,:));
   if helge == 0, 
        pstardel = xdel;
        elseif helge == 1, 
            for j = 1:cx,
            pstardel(:,j) = hsquasher(xdel(1,j), smax, smin, maxx(1,j), minx(1,j)); 
            end  
        elseif helge == 2,
        pstardel = 1 ./ (1+exp(-pstardel));
        pstardel = real(pstardel);
        else 
            for jj = 1:cx,
            pstardel(:,jj) = (xdel(:,jj) - kron(ones(rxstar,1),minx(1,jj))) ./ (maxx(jj) - minx(jj));
            end
      
    end
  
    if nlayer == 1, 
        A3d =  pstardel * W3+ b3;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W4 + b4;
        elseif nlayer == 2,
        A3d = pstardel * W3+ b3;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W4 + b4;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W5 + b5;
        else A3d = pstardel * W3+ b3;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W4 + b4;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W5 + b5;
        A3d = 1./(1+exp(-A3d));
        A3d = A3d * W6 + b6;
    end
    if helge == 0, A3d = A3d;
        elseif helge == 1, 
        A3d = A3d;
            for kk = 1:cy,
            A3d(1,kk) = helgeyx(A3d(1,kk), maxy(kk), miny(kk),smax,smin);
            end
        A3d = A3d;
        A3d = real(A3d);
        elseif helge == 2,
        A3d = A3d;
        A3d = -log(1./A3d - ones(size(A3d)));
        A3d = meany + A3d .* sigy;
        A3d = real(A3d);
        else 
            for j=1:cy,
            A3d(:,j) =  A3d(:,j) .* (maxy(j)-miny(j)) + miny(j);
            end;
    end
        if cy > 1, pderdum(:,:,i) = (A3d-A3star) ./ hdelta;
        else pdernum(:,i) = (A3d-A3star) ./ hdelta;
        end
    clear A3d xdel; 
end
   


xout  = [x(nrow11:nrow,:)];
yout = y(nrow11:nrow,:);
[n1 c1] = size(yout);
Poutraw = xout;
Poutraw1 = [Poutraw ones(n1,1)];
Toutraw = yout;
T1 = TN(nrow1+1:end,:);
P1 = PN(nrow1+1:end,:);
A11 = Poutraw1 * betaols;
yhatls1 = A11;
err11 = yout - yhatls1;
err11sq = err11 .^2;
rmsqe1 = sqrt(mean(err11sq));
[rp1, cp1] = size(P1);
if nlayer == 1, 
    
    A31 = P1 * W3+ kron(ones(rp1,1),b3);
    A31 = 1./(1+exp(-A31));
    A31 = A31 * W4 + kron(ones(length(A31),1),b4);
elseif nlayer == 2,
    A31 = P1 * W3+ kron(ones(rp1,1),b3);
    A31 = 1./(1+exp(-A31));
    A31 = A31 * W4 +kron(ones(length(A31),1),b4);
    A31 = 1./(1+exp(-A31));
    A31 = A31 * W5 + kron(ones(length(A31),1),b5);
  
else
  A31 = P1 * W3+ kron(ones(rp1,1),b3);
  A31 = 1./(1+exp(-A31));
  A31 = A31 * W4 + kron(ones(length(A31),1),b4);
  A31 = 1./(1+exp(-A31));
   A31 = A31 * W5 + kron(ones(length(A31),1),b5);
  A31 = 1./(1+exp(-A31));
  A31 = A31 * W6 + kron(ones(length(A31),1),b6);
end

if helge == 0, yhatnet1 = A31;
    elseif helge == 1, A31z = A31;
        for i = 1:cy,
        A31x(:,i) = helgeyx(A31z(:,i),maxy(i), miny(i), smax, smin);
        end
   A31net = A31x; 
   yhatnet1 = A31net;
elseif helge == 2,
    A31z = A31;
      A31x = -log(1./A31z - ones(size(A31z)));
    A31x = real(A31x);
    A31x = kron(ones(n1,1),meany) + A31x .* kron(ones(n1,1), sigy);
    A31net = A31x; 
    yhatnet1 = A31net;
else  
    for i = 1:cy, 
        A31net(:,i) = A31(:,i) .* (maxy(i)-miny(i)) + miny(i);
    end
   	yhatnet1 = A31net;
end
err31 = yout-yhatnet1;
err31sq = err31 .^2;
rmsqe3 = (mean(err31sq)) .^.5;
rmsqe = [rmsqe1; rmsqe3];
% hintonwb(W3,b3); pause
% subplot(211); barerr(err1); grid; subplot(212); barerr(err3); grid; pause
% subplot(211); barerr(err11); grid; subplot(212); barerr(err31); grid;
hqnet = hqif(ncoly+1:end,:);
pdernetc = pdernum; 
w1net = W3;
w2net = W4;
w3net = W5;
w4net = W6;
ssebest = sse;
rsqbest = [ssrsq];
rmsqbest = real([rmsqe]);
hqifbest = [hqif];

pderbest = [W1'; pdernetc];
w1best = w1net;
w2best = w2net;
w3best = w3net;
w4best = w4net;
b1best = b3;
b2best = b4;
b3best = b5;
b4best = b6;
yyyhat = yhat;
yyyout = [yout yhatls1 yhatnet1];
yout = yyyout;
ndim = ncoly;
for i = 1:ndim,
   erroroutls(:,i) = yout(:,ndim+i) - yout(:,i); 
   erroroutnet(:,i) = yout(:,2*ndim+i) - yout(:,i); 
   rrmsq(1,i) = sqrt(mean(erroroutls(:,i) .^2));
   rrmsq(2,i) = sqrt(mean(erroroutnet(:,i) .^2));
end
rmsqbest = rrmsq;
clear global P T nlayer nneuron1 nneuron2 nneuron3;