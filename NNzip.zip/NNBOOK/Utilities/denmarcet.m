
function [dmstat, dmsig] = denmarcet(difflambda, instruments, nlag);
% Den Haan and Marcet Test of Accuracy in Simulations
% Inputs:  beta * lambda - lambda(t-1), instruments, lags
% Output:  dmstat, dmsig: determined by chi-squared for degress of freedom
%       equal to column of instruments times nlag
xxx = mylag(instruments, nlag);
[rowx, colx] = size(xxx);
xxxx = diff(xxx);
yyyy = difflambda(nlag+1:end,:);
yyyy = yyyy(2:end,:);
aaa = inv(xxxx' * xxxx) * xxxx'* yyyy ;
[T2, R2] = size(yyyy);
for i = 1:T2,
   bbb1(i,:) =  kron(yyyy(i,1), xxxx(i,:));
   end
   bbb = bbb1' * bbb1; 
   bbbi = inv(bbb);
dmstat = aaa' * (xxxx' * xxxx) * bbbi * (xxxx' * xxxx) * aaa;
dgf = colx;
dmsig = 1 - chi2cdf(dmstat, dgf);