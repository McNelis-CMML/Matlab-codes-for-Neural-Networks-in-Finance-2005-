function y = hsquasher(x, ymax, ymin, xmax, xmin);
%  squasher function developed by Helge Petersohn
%  inputs:  x, ymax, ymin
if nargin == 3,
xmax = max(x);
xmin = min(x);
else xmax = xmax; xmin = xmin;
end
A = log((1 / ymax) - 1) - log((1/ymin) - 1);
A = A / (xmax - xmin);
B = log((1/ymin) - 1);
y = 1 ./ (1 + exp(A * (x - xmin) + B));