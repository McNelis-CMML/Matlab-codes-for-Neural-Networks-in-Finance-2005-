function [error, yhat, Jstat, Jsig, neuron1, V, SIGB] = cm_mod2_gmm(beta);
global squasher data1 minx miny maxx maxy malags nwlags instlags z nwestdum 
global neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol LAMBDA arlags;
% beta = abs(beta);
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x(:,1:2+arlags));
[nxx, cxx] = size(x);
ny = length(y);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cxx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end

% z = mylag(x(:,[arlags 2+arlags+1:2+arlags+2]), instlags);

yy = y(instlags+1:end,:);
xx = x(instlags+1:end,:);
[nxxx, cxxx] = size(xx);
yhat = yy;
if squasher == 1,
    cxarg_ygap = (cthres_ygap-minx(neuronxarg_ygap)) / (maxx(neuronxarg_ygap)-minx(neuronxarg_ygap));
else cxarg_ygap = cthres_ygap;
end
neuronx = abs(beta(cx+2))* (xx(:,neuronxarg_ygap)-cxarg_ygap);
neuron1 =  2 ./ (1 + exp(-2 * neuronx))-1;
yhat1 = xx(:,1:cx) * abs(beta(1:cx))' +  beta(cx+1)  -  neuron1 .* abs(beta(neuronxarg_ygap)) .* xx(:,neuronxarg_ygap);
nparm =  cx + 2;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat1 = y(instlags+1:end,:) - yhat;
[nz, cz] = size(z);
mm = z' * ehat1 / ny;
mhat = mm(:);
mm1 = repmat(ehat1,1, cz) .* z;
S = diag(diag(cov(mm1)));
[LS, CS] = size(S);
if nwestdum == 0,
vm = S\eye(CS);
else vm = neweywest(mm1, nwlags); vm = vm\eye(CS);
end
error = mm' * vm * mm;
Jstat = error * ny;
dgf = cz - length(beta);
Jsig = 1 - chi2cdf(Jstat, dgf);
xxn = (ones(length(xx),1) - neuron1 .* neuron1);
xxx = [xx(:,1:neuronxarg_ygap-1) xx(:,neuronxarg_ygap)+ neuron1 .* xx(:,neuronxarg_ygap)  ones(length(xx),1) ...
    beta(neuronxarg_ygap) * xxn .* (xx(:,neuronxarg_ygap)-cxarg_ygap)];
M = kron(eye(1),-z'*xxx/length(xxx));
V1 = inv(M' * vm * M);
V = V1 ./ nz;
SIGB = real(sqrt(diag(V)))';
[ns, cs] = size(SIGB);
for j = 1:cs, 
    if SIGB(j) == 0, 
    SIGB(j) = .001; 
    end
end







