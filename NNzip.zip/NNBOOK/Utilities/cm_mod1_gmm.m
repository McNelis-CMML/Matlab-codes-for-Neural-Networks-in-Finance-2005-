function [error, yhat, Jstat, Jsig, neuron1, V, SIGB] = cm_mod1_gmm(beta);
global squasher data1 minx miny maxx maxy malags nwlags instlags z nwestdum 
global neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol LAMBDA arlags;
% beta = abs(beta);
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x(:,1:2+arlags));
[nxx, cxx] = size(x);
ny = length(y);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cxx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
yy = y(instlags+1:end,:);
xx = x(instlags+1:end,:);
[nxxx, cxxx] = size(xx);
if squasher == 1,
    cxarg_inf = (cthres_inf-minx(neuronxarg_inf)) / (maxx(neuronxarg_inf)-minx(neuronxarg_inf));
else cxarg_inf = cthres_inf;
end
neuronx = abs(beta(cx+2)) * (xx(:,neuronxarg_inf)-cxarg_inf);
neuron1 =  2 ./ (1 + exp(-2 * neuronx))-1;
yhat1 = xx(:,1:cx) * abs(beta(1:cx))' +  beta(cx+1) + neuron1 .* abs(beta(neuronxarg_inf)) .* xx(:,neuronxarg_inf);
nparm =  cx + 2 + malags;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat1 = y(instlags+1:end,:) - yhat;
[nz, cz] = size(z);
mm = z' * ehat1 / ny;
mhat = mm(:);
mm1 = repmat(ehat1,1, cz) .* z;
S = diag(diag(cov(mm1)));
[LS, CS] = size(S);
if nwestdum == 0,
vm = S\eye(CS);
else vm = neweywest(mm1, nwlags); vm = vm\eye(CS);
end
error = mm' * vm * mm;
Jstat = error * ny;
dgf = cz - length(beta);
Jsig = 1 - chi2cdf(Jstat, dgf);
xxn = (ones(length(xx),1) - neuron1 .* neuron1);
xxx = [xx(:,1:neuronxarg_inf-1) xx(:,neuronxarg_inf)+ neuron1 .* xx(:,neuronxarg_inf)...
    xx(:,neuronxarg_inf+1) ones(length(xx),1) beta(neuronxarg_inf) * xxn .* (xx(:,neuronxarg_inf)-cxarg_inf)];
M = kron(eye(1),-z'*xxx/length(xxx));
V1 = inv(M' * vm * M);
V = V1 ./ nz;
SIGB = real(sqrt(diag(V)))';
[ns, cs] = size(SIGB);
for j = 1:cs, 
    if SIGB(j) == 0, 
    SIGB(j) = .001; 
    end
end








