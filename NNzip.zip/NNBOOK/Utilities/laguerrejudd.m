function lagx = laguerrejudd(x, degree);
[rr, cc] = size(x);
lagxx(:,1) = ones(rr,1);
lagxx(:,2) = 1-x;
for i = 3:degree,
    counter1 = 1 / i;
    counter2 = 2 .* (i-1) + 1 - x;
    counter3 = (i-1)/i;
    lagxx(:,i) = counter1 .* counter2 .* lagxx(:,i-1) - counter3 .* lagxx(:,i-2);
end
lagx = lagxx(:,2:end);