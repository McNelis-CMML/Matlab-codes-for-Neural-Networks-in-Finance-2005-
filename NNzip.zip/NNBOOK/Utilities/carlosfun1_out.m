function [error, yhat, pderiv] = carlosfun1_out(beta);
global data1 squasher;
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
ny = length(y);
yhat1 = y; 
ehat = zeros(nx,1);
xx0 = x * beta(1:cx)' + ones(ny,1) * beta(cx+1);
yhat1 =  xx0 ;
end;
nparm = cx + 13;
error = y - yhat1;
error = sum(error .^2);
       
loglik = 0;

error = -loglik;
yhat = yhat1; 
for i = 1:cx,
pderiv(:,i) = beta(i); 
end;





