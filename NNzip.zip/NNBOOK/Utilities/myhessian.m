function hh = myhessian(fun, beta, lambda);
% computes hessian, inputs function, beta lambda
% uses function myjacobian
[rr, k] = size(beta);
vec1 = zeros(1,k);
jac = myjacobian(fun, beta, lambda);
for i = 1:k,
vec1(i) = max(lambda, lambda * beta(1,i));
   betax = beta + vec1;
   jacx = myjacobian(fun, betax, lambda);
   hhx = jacx - jac;
   hh(i,:) = hhx ./ vec1(i);
   vec1 = zeros(1,k);
   betax = beta;
end
