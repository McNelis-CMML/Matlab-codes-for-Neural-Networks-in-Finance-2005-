function [loglik, yhat, neuron1] = cm_mod2_mlik(beta);
global squasher data1 minx miny maxx maxy malags nwlags neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol LAMBDA CMDUM ;
% beta(1) = 1 / (1+exp(-beta(1)));
y = data1(:,1);
x = data1(:,2:end-1);
[nx, cx] = size(x);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg_ygap = (cthres_ygap-minx(neuronxarg_ygap)) / (maxx(neuronxarg_ygap)-minx(neuronxarg_ygap));
else cxarg_ygap = cthres_ygap;
end
ny = length(yy);
if CMDUM == 0,
    neuronx = abs(beta(cx+2))*(xx(:,neuronxarg_ygap)-cxarg_ygap);
else  neuronx = LAMBDA *(xx(:,neuronxarg_ygap)-cxarg_ygap);
end
neuron1 =  2 ./ (1 + exp(-2 * neuronx))-1;
if CMDUM == 0,
yhat1 = xx(:,1:cx) * abs(beta(1:cx))' +  ((beta(cx+1)))  - neuron1 .* xx(:,neuronxarg_ygap) * abs(beta(neuronxarg_ygap));
else yhat1 = xx * abs(beta(1:cx))' +  ((beta(cx+1)))  - neuron1 .* abs(beta(cx+2)) .* xx(:,neuronxarg_ygap);
end

if malags > 0, 
ehat1 = zeros(malags,1);
for i = malags +1: ny,
    EXX = ehat1(i-malags:i-1,:);
    yhat1(i,:) = yhat1(i,:) + beta(cx + 3: end) * EXX;
    ehat1(i,:) = yy(i,:) - yhat1(i,:);
end
end
nparm =  cx + malags + 2;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat = y - yhat;
error = ehat;  
errorsq = (error .^2);
T = length(yhat); 
sigmavar = sum(errorsq)/ (T-nparm);  
sigmastd = sqrt(sigmavar);
errornorm = error ./ sigmastd;
loglik1 = -.5 * T * log(2 * pi) - .5 * T * log(sigmavar) - .5 *  sum(errornorm.^2) ;
loglik = -loglik1;





