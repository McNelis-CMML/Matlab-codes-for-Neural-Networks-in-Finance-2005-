function pderivn = logsigderx(pbar, W3, b3, W4, b4, W5,b5,W6, nlayer);
global nneuron1 nneuron2 nneuron3;
% pderivn = logsigder(pbar, gamma, omega, omega0);
if nlayer == 1;
   omega0 = b3'; omega = W3;
   gamma = W4;
nnbar = omega0 + omega * pbar;
nnbar = logsig(nnbar);
nbar = nnbar .* (1-nnbar);
nbar = gamma .* nbar';
pderivn = nbar * omega;
elseif nlayer == 2;
   nnbar = b3' + W3 * pbar;
   nnbar = logsig(nnbar);
   nbar = nnbar .* (1-nnbar);
   nbar = W4 .* kron(ones(nneuron2,1),nbar');
   nn2bar = b4' + W4 * nnbar;
   nn2bar = logsig(nn2bar);
   n2bar = nn2bar .* (1- nn2bar);
   n2bar = W5  .* n2bar';
   pderivn = n2bar * nbar * W3;
else
   nnbar = b3' + W3 * pbar; % n1 x 1
   nnbar = logsig(nnbar);
   nbar = nnbar .* (1-nnbar); % n1 x 1
   nbar = W4 .* kron(ones(nneuron2,1), nbar');  % nbar is n1 by 1
   nn2bar = b4' + W4 * nnbar; % w4 is n2 x n1, nn2bar is n2 x 1
   nn2bar = logsig(nn2bar);
   n2bar = nn2bar .* (1- nn2bar);
   n2bar = W5  .* kron(ones(nneuron3,1), n2bar');  %W5 is n3 by n2, n2 bar is n2 by 1
   nn3bar = b5' + W5 * nn2bar; % n3 by 1
   nn3bar = logsig(nn3bar);
   n3bar = nn3bar .* (1-nn3bar);
   n3bar = W6 .* n3bar'; % W6 is 1 by N3
   pderivn = n3bar * n2bar * nbar * W3;
   end
   

   
  
   