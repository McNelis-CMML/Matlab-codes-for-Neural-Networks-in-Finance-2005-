%  COLD.M
%  DELETES COL n OF MATRIX A AND PUTS RESULT IN MATRIX B
%  B=cold(A,n)
										
function[B]=cold(A,n)
[m1,m2]=size(A);
B=[A(:,1:n-1),A(:,n+1:m2)];

