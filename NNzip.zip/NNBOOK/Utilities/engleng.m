function [tstatb, lmstat, msig] = engleng(y);
% Engle and Ng Test for Asymmetry in Shocks
% input: data, output: tstat, lm stat, marginal significance
sy = std(y);
mu = mean(y);
epsi = y - mu;
v = (y - mu) ./ sy;
v2 = v .^ 2;
[nn cc] = size(y);
for i = 1:nn, if epsi(i,:) < 0, sneg(i,:) = 1; else sneg(i,:) = 0; end; end;
for i = 1:nn, if epsi(i,:) > 0, spos(i,:) = 1; else spos(i,:) = 0; end; end;
sposy = spos .* epsi;
snegy = sneg .* epsi;
x = [ones(nn,1) sneg snegy sposy];
v2 = v2(2:nn,:);
x = x(1:nn-1,:);
[beta, sigbeta, resid, rsq] = ols(x,v2);
tstatb = beta ./ sigbeta;
tstatb = tstatb(2:4);
lmstat = (nn-1) .* rsq;
msig = 1 - chi2cdf(lmstat,3);


   