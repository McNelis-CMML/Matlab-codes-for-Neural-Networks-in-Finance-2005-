function x = helgeyx(y,xmax, xmin,ymax, ymin);
%  squasher function developed by Helge Petersohn
%  inputs:  y, xmax, xmin, ymax, ymin
A = log((1 / ymax) - 1) - log((1/ymin) - 1);
A = A / (xmax - xmin);
B = log((1/ymin) - 1);
x = log((1 ./ y)-1) - B;
x = x / A;
x = x + xmin;