function [alpha, talpha] = unitroot(ydata);
% Inputs:  ydata
% Ouputs: coefficient with no constant, coeff with constant, coeff with const and time
 [nrow, ncol] = size(ydata);
 ydep = diff(ydata);
 ydep = ydep(2:end,:);
 x = ydata(1:end-2,:);
 [nrow1, ncol] = size(ydep);
 time1 = 1:nrow1; time1 = time1'; 
for i = 1:ncol,
   [junk1, tjunk1] = ols1(x(:,i), ydep(:,i)); 
   alpha(1,i) = junk1(1); talpha(1,i) = tjunk1(1);
   [junk2, tjunk2] = ols1([x(:,i) ones(nrow1,1)],ydep(:,i));
   alpha(2,i) = junk2(1); talpha(2,i) = tjunk2(1);
   [junk3, tjunk3] = ols1([x(:,i) ones(nrow1,1) time1],ydep(:,i));
   alpha(3,i) = junk3(1); talpha(3,i) = tjunk3(1);
end
    
    
       