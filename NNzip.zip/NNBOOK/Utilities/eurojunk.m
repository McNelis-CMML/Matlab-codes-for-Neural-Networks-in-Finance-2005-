clear all
INSTLAGS = 8;
NWLAGS = 24;
usa_taylor_gmm_feb2005;
save usa_gmm_march14a;
clear all;
INSTLAGS = 8;
NWLAGS = 24;
euro_taylor_gmm_feb2005;
save euro_gmm_march14a;
clear all;
