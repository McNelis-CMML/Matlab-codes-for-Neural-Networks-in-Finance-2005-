function [error, yhat, yhatnn] = nnstrsfun_out(beta);
global data1 squasher maxx minx maxy miny neuronxarg;

y = data1(:,1);
x = data1(:,2:end);

[nx, cx] = size(x);

if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg = -minx(neuronxarg) / (maxx(neuronxarg)-minx(neuronxarg));
else cxarg = 0;
end
ny = length(yy);
xx0 = xx * beta(1:cx)';
neuron1 = 1 ./ (1 + exp(-xx * beta(cx+1:2*cx)'));
neuron2 = 1 ./ (1 + exp(-xx * beta(2*cx+1:3* cx)'));
neuron3x = beta(3*cx+2)* (xx(end,neuronxarg)-cxarg);
neuron3 =  1 ./ (1 + exp(-neuron3x));
yhat1 = beta(3*cx+1) + xx0 + neuron3 * neuron1 + (1- neuron3) *   neuron2; 
nparm = 3 * cx + 14;
error = yy - yhat1;
loglik =0;
yhatnn = neuron3 * neuron1 + (1- neuron3) *   neuron2; 
error = -loglik;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
if squasher == 1,
    yhatnn = yhat * (maxy-miny) + miny;
else yhatnn= yhatnn;
end;

    




