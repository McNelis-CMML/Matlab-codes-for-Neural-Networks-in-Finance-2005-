function [error, yhat, pderiv,neuron1, neuron2] = cm_mod3(beta);
global squasher data1 minx miny maxx maxy malags neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol ;

y = data1(:,1);
x = data1(:,2:end-1);
[nx, cx] = size(x);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg_ygap = (cthres_ygap-minx(neuronxarg_ygap)) / (maxx(neuronxarg_ygap)-minx(neuronxarg_ygap));
    cxarg_inf = (cthres_inf-minx(neuronxarg_inf)) / (maxx(neuronxarg_inf)-minx(neuronxarg_inf));
else cxarg_ygap = cthres_ygap;  cxarg_inf = cthres_yinf;
end

ny = length(yy);
yhat1 = yy; 
% xx1 = xx * abs(beta(1:cx))' + ones(ny,1) * abs(beta(cx+1));
xx1 = xx * (beta(1:cx))' + ones(ny,1) * abs(beta(cx+1));
ehat(1:malags,1) = zeros(malags,1); 
neuron1(1:malags,1) = zeros(malags,1);
neuron2(1:malags,1) = zeros(malags,1); 


for i = malags+1:ny, 
% neuronx1 = abs(beta(cx+2))* (xx(i-1,neuronxarg_ygap)-cxarg_ygap);
neuronx1 = abs(beta(cx+2))* (xx(i-1,neuronxarg_ygap)-cxarg_ygap);

neuron1(i,:) =  2 ./ (1 + exp(-2 * neuronx1)) -1;

% neuronx2 = abs(beta(cx+3))* (xx(i-1,neuronxarg_inf)-cxarg_inf);
neuronx2 = abs(beta(cx+3))* (xx(i-1,neuronxarg_inf)-cxarg_inf);

neuron2(i,:) =  2 ./ (1 + exp(-2 * neuronx2)) -1;

EXX = ehat(i-malags:i-1,:);
% yhat1(i,:) = xx1(i,:)  + neuron1(i,:) * abs(beta(neuronxarg_ygap)) * xx(i,neuronxarg_ygap) + ...
%     neuron2(i,:) * abs(beta(neuronxarg_inf)) * xx(i,neuronxarg_inf) + beta(cx + 4:cx+malags+3) * EXX;

yhat1(i,:) = xx1(i,:)  + neuron1(i,:) * (beta(neuronxarg_ygap)) * xx(i,neuronxarg_ygap) + ...
    neuron2(i,:) * (beta(neuronxarg_inf)) * xx(i,neuronxarg_inf) + beta(cx + 4:cx+malags+3) * EXX;

ehat(i,:) = yy(i,:) - yhat1(i,:);
end;
nparm =  cx + malags+3;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
error = y - yhat;
error1 = (error .^2);
T = length(yhat); 
sigma = sum(error1)/ (T-nparm);  
loglik = -.5 * T * log(2 * pi) - .5 * T * log(sigma) - .5 * inv(sigma) *  sum((error).^2) ;
error = -loglik;
for i = 1:cx,
for j = 2:ny,
    pderiv(j,i) =   abs(beta(i));
end;
end;
for j = 2:ny,
    pderiv(j,neuronxarg_ygap) = abs(beta(neuronxarg_ygap)) + neuron1(j) * abs(beta(neuronxarg_ygap)); 
    pderiv(j,neuronxarg_inf) = abs(beta(neuronxarg_inf)) + neuron2(j) * abs(beta(neuronxarg_inf));
end;
    




