     for j = 1:1000,
     % Matlab Program For Assessing Approximation
     randn('state',j);
     x1 = randn(1000,1); 
     y1= sin(x1).^2 + exp(-x1);
    x = ((2 * x1) ./ (max(x1)-min(x1))) - ((max(x1)+min(x1))/(max(x1)-min(x1)));
    y = ((2 * y1) ./ (max(y1)-min(y1))) - ((max(y1)+min(y1))/(max(y1)-min(y1)));
      % Compute linear approximation
     xols = [ones(1000,1) x];
     bols = inv(xols'*xols)*xols'* y;
     rsqols(j) = var(xols*bols)/var(y);
     % Polynomial approximation
     xp = [ones(1000,1) x x.^2];
     bp = inv(xp'*xp)*xp'*y;
     rsqp(j) = var(xp*bp)/var(y);
     % Tchebeycheff approximation
     xt = [ones(1000,1) chebjudd(x,3)];
     bt = inv(xt'*xt)*xt'*y;
     rsqt(j) = var(xt * bt)/var(y);
     % Hermite approximation
     xh = [ones(1000,1) hermitejudd(x,3)];
     bh = inv(xh'*xh)*xh'*y;
     rsqh(j)= var(xh * bh)/var(y);
     % Legendre approximation
     xl = [ones(1000,1) legendrejudd(x,3)];
     bl = inv(xl'*xl)*xl'*y;
     rsql(j)= var(xl * bl)/var(y);
     % Leguerre approximation
     xlg = [ones(1000,1) laguerrejudd(x,3)];
     blg = inv(xlg'*xlg)*xlg'*y;
     rsqlg(j)= var(xlg * blg)/var(y);
     % Neural Network Approximation
     data = [y x];
     position = 1; % column number of dependent variable
     architecture = [1 2 0 0]; % feedforward network with one hidden layer, with two neurons
     geneticdummy = 1; % use genetic algorithm
     maxgen =20; % number of generations for the genetic algorithm
     percent = 1; % use 100 percent of data for all in-sample estimation
     nlags = 0; % no lags for the variables
     ndelay = 0; % no leads for the variables
     niter = 20000; % number of iterations for quasi-Newton method
     [sse, rsqnet01] = ffnet9(data, position, percent, nlags, ndelay, architecture, ...
     geneticdummy, maxgen, niter) ;
     rsqnet0(j) = rsqnet01(2);
     RSQ(j,:) = [rsqols(j) rsqp(j) rsqt(j) rsqh(j) rsql(j) rsqlg(j) rsqnet0(j)]
    end