function [beta, tstat,rsq, dw,jbstat,engle, qstat1,qstat2] = ols1(X,y);
%  OLS function with diagnostics
%  Input: X,y
%  Output: beta, tstat, rsq, dw, jbstat, engle, qstat1(1), qstat2(2)
[beta,se,resid,r2,rb2]=ols(X,y);
rsq = r2;
[nn,cc] = size(X);
dgf = nn-cc;
tstat = beta ./ se;
tmsig = 1 - tcdf(abs(tstat), dgf);
tstat = [tstat tmsig];
dw = durbinwatson(resid);
[entlet, lmstat, lmsig] = engleng(resid);
engle = [lmstat lmsig];
[qstat1 q1msig] = qstatlb(resid,1,0);
qstat1 = [qstat1 q1msig];
[qstat2 q2msig] = qstatlb(resid .^ 2, 1,0);
qstat2 = [qstat2 q2msig];
[jbstat, jbsig] = jarque(resid,0);
jbstat = [jbstat jbsig];