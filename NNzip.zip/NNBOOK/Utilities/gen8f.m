function [CONTROLB, sumutilb] = gen5f(fun, beta0, popsize, maxgen)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [CONTROLB, sumutilb] = gen5d(fun,beta0,popsize, maxgen)
% It requires: global TICTOC
% but it uses or create the following global variables
% global ELITE CURVAU TOLER PMSTART PDES EXPONB 
% global SCALE PSHUFFLE PLINEAR PMEND PC INTERVISION
% global  CONTROLB    % THIS SET OF PARAMETERS IS GLOBAL TO STOP THE
% ITERATIONS
%
% Inputs:         fun     : Function
%                 beta0   : Initial Parameters 
%                 popsize : Population size
%                 maxgen  : Number of generations
%      optionals  by a global variables
%                 ELITE   : ~0   (0) no keep old generation 
%                 CURVAU  : .75   pondera on fit
%                 TOLER   : .011 toler in` error
%                 PDES    : .05     population destruction 
%                 EXPONB  : 2     change in mutation
%                 SCALE   : 1     scale for new population
%                 PSHUFFLE: .33   value of mix parameters
%                 PLINEAR : .33   value of linear combinarion of param
%                 PMEND   : .15   value of initial mutation
%                 CONTROLP: 0.95  if modify the parameters
%                 PMSTART : .35   mobil value of mutation
% Output:         controlg: parameter that minimize the function
%                 sumutilb: minimum value of the function
% partial vision
% time , generation, max generation,
% minimun error in this generation, global minimo
%
% Chuchu, from early version of P. McNelis
% JUN 4, 2003
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin < 4; error(' must have fun, beta0, popsize maxgen');end, 
global ELITE CURVAU TOLER PMSTART PDES EXPONB 
global SCALE PSHUFFLE PLINEAR PMEND PCONTROL INTERVISION
global CONTROLB
%  default values for optional input
if isempty(INTERVISION),    INTERVISION= 1;       end
if isempty(PMSTART),        PMSTART = .35;        end
if isempty(PCONTROL),       PCONTROL= .95;        end
if isempty(PMEND),          PMEND   = .15;        end
if isempty(PLINEAR),        PLINEAR = .33;        end
if isempty(PSHUFFLE),       PSHUFFLE= .33;        end
if isempty(SCALE),          SCALE   = 1;          end
if isempty(EXPONB),         EXPONB  = 2;          end
if isempty(PDES),           PDES    = .050;        end
if isempty(TOLER),          TOLER   = .001;       end
if isempty(CURVAU),         CURVAU  = .75;        end
if isempty(ELITE),          ELITE   = 1;          end
[junk nparm] = size(beta0);
www = zeros(popsize,nparm);
sse100 = zeros(1,popsize);
lwww = zeros(1,popsize);
swww = zeros(1,popsize);
nnrow = zeros(2,1);
s = zeros(2,nparm);
if junk ~=1; error(' beta0 is not a column vector');end
www(1,:)= beta0;
lwww=popsize:-1:1;    lwww=lwww.^CURVAU;     swww=lwww/sum(lwww);
for i=2:popsize,                swww(i)=sum(swww(i-1:i));           end
rand('state',exp(abs(randn*randn))); %change state rand
for repl = 1:maxgen,              % begin generation
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if (rand < PDES | repl==1)      % population new or destroyed
    if repl==1
      popsize=max(popsize,2*nparm);
%       fprintf(' Up to %d generation , with  % d  popsize\n',maxgen, popsize);
      www = [www(1,:); (randn(popsize-1,nparm)).* SCALE]; 
      for i = 1:popsize,
        sse100(i)   =  feval(fun,www(i,:));
      end
    else
%       if INTERVISION==1
%         fprintf(' partial destruction  genration: % d \n',repl);
%       end
      if ELITE==0;
        www=[CONTROLB;www];
      end
      www = [www(1:nparm,:); (randn(popsize-nparm,nparm)).* SCALE]; 
      for i = nparm+1:popsize,
        sse100(i)   =  feval(fun,www(i,:));
      end
    end
    [sse100 inds] =sort(sse100);  www=www(inds,:);
    sumutilb=sse100(1);
    CONTROLB=www(1,:);
  end;
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  % cambio en mutacion 
  maxg=rand/EXPONB/repl;
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  for ii = 1:2:popsize,           % begin tournament 
    for i=1:2;                nnr=rand;      % choose parents             
      [junk ind]=min(abs(swww-nnr));
      if (swww(ind)-nnr)<0; ind=ind+1;end,   nnrow(i)=ind;
    end
    %    if (ii ==1),           nnrow(1)    = 1;           end
    p1  = nnrow(1);           p2          = nnrow(2);  
    % creation of childs: shuffle, linear comb, cutpoint or without modif
    if rand         <= PCONTROL,        randy       = rand;
      if randy      < PSHUFFLE,   rrr         = rand(1,nparm) > .5;
        child1      =www(p1,:);   child2      = www(p2,:);
        child1(rrr) =www(p2,rrr);        child2(rrr) = www(p1,rrr); 
      elseif randy < (PSHUFFLE + PLINEAR),      aaa = rand(1,nparm);
        child1 = aaa .* www(p1,:) + (1-aaa) .* www(p2,:);
        child2 = aaa .* www(p2,:) + (1-aaa) .* www(p1,:);
      else          
        cutpoint  = round(rand * (nparm-2))+1 ;
        child1    = [www(p1,1:cutpoint) www(p2, cutpoint+1:nparm)];
        child2    = [www(p2,1:cutpoint) www(p1, cutpoint+1:nparm)]; 
      end
    else, child1  = www(p1,:);    child2      = www(p2,:); 
    end
    
    % mutation of childs     % pm: critacal value to change
    pm      = PMEND + (PMSTART - PMEND) / repl; 
    % which will be mutated and  which are plus or minus
    rr1     = [rand(2,nparm) <= pm] .* ([(rand(2,nparm) > 0.5)] * 2 - 1);
    % amount of mutation 
    s       = rand(2,nparm) .* (1-(rand(2,nparm).^maxg));
    % new childs and value of function with these parameters
    child1  = child1 +rr1(1,:) .* s(1,:);     schild1 = feval(fun,child1);
    child2  = child2 +rr1(1,:) .* s(2,:);     schild2 = feval(fun,child2);
    %  disp([schild1 schild2 p1 p2]);
    % new tournament between parents and childs
    nwww(ii+[0 1],:)  = [child1; child2]; 
    nsse(ii+[0 1])    = [schild1; schild2]; 
  end
  if ELITE==0
    [sse100, ind] = sort(nsse);   
    sse1001=sse100(1);
    if sse100(1)<sumutilb;
      CONTROLB  = nwww(ind(1),:);
      sumutilb  = sse100(1);
    end
    www       = nwww(ind,:);
    ssemean   = mean(sse100);
  else    
    [nsse ind]=sort(nsse);
    nwww=nwww(ind,:);
    nwww=[www(1,:);nwww(1:end-1,:)];
    nsse=[sse100(1),nsse(1:end-1)];
    [sse100, ind] = sort(nsse);    
    CONTROLB  = nwww(ind(1),:);
    sumutilb  = sse100(1);
    www       = nwww(ind,:);
    ssemean   = mean(sse100);
    sse1001   =sse100(1);
    sumutilb =sse100(1);
  end
%   if INTERVISION==1;
%     disp([toc/60 repl maxgen sse1001 sumutilb ]);
%   end
  
  if sumutilb<TOLER
    disp('success toler'); 
    return
  end
  clear rrr1 child1 child2 schild1 schild2 wwwc ssec ssez indc nwww 
  clear ssemean nnrow p1 p2 pp randy aaa cutpoint nsse nsse1 s
end
