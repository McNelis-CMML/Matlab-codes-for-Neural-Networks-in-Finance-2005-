function [error, yhat] = strsfun_out(beta);
global data1 squasher maxx minx maxy miny neuronxarg cthres;
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
% beta(1:2*cx+3) = abs(beta(1:2*cx+3));
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
cthres = 0;
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg = (cthres-minx(neuronxarg)) / (maxx(neuronxarg)-minx(neuronxarg));
else cxarg = cthres;
end
ny = length(yy);
xx1 = xx * beta(1:cx)' + ones(ny,1) * beta(2*cx+1);
xx2 = xx * beta(cx+1:2*cx)' + ones(ny,1) * beta(2*cx+2);
xx11 = xx1(2:end,:);
neuron1 = xx11;
xx22 = xx2(2:end,:);
neuron2 = xx22;
xx33 = xx(1:end-1,neuronxarg);
neuron3x = abs(beta(2*cx+3))* (xx33-cxarg);
neuron3 =  1 ./ (1 + exp(-neuron3x));
yhat1 = neuron3 .* neuron1 + (1- neuron3) .*   neuron2; 

nparm = 2 * cx + 15;
error = yy(2:end,:) - yhat1;
error = sum(error .^2);
sigma = error/ nparm;  
T = length(yhat1);          
loglik = 0;
error = -loglik;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
if isnan(yhat) == 1, yhat = 0; end
if isempty(yhat) == 1, yhat = 0; end;
    




