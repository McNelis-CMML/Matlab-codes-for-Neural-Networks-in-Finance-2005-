function dwstat = durbinwatson(data);
[rows cols] = size(data);
ss = data' * data;
dd = diff(data);
ssdd = dd' * dd;
for j = 1:cols,
dwstat(j) = ssdd(j,j) ./ ss(j,j);
end