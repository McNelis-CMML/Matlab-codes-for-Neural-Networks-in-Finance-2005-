function x = mylag(datmat, nlag);
yrhat = [datmat];
lag1 = nlag + 1;
[tr cr] = size(yrhat);
cc = cr;
yrx = yrhat(lag1:tr,:);
j = 1:cr:(cr*lag1);
xxxx =  zeros(tr-nlag, nlag * cr);
for i = 1:nlag,
xxxx(:,j(i):j(i+1)-1) = yrhat(lag1-i:tr-i,:);
end 
x = xxxx;
nnarg = nlag * cc;
lll = 0;
for jjj = 1:cc,
for iii = jjj:cc:nnarg,
lll = lll + 1;
xx(:,lll) = x(:,iii); end
end
x = xx;





