 function [LIK,ssr,yhat, pderiv] = logit(beta1);
 %  Input: beta1, global data1 (y,x)
 %  Output: LIK, ssr, yhat, pderiv
 global P T;
 y = T;
 x = P;
 [rx, cx] = size(x);
bx = x * beta1(1:end-1)' + ones(length(x),1) * beta1(end);
yhat = 1 ./ (1 + exp(-bx));
ssr = (y - yhat)' * (y-yhat);
[rr cc] = size(y);
% lik = (yhat .^y) .* ((1-yhat).^(1-y));
lik = y .* log(yhat) + (1-y) .* log(1-yhat);
% LIK = log(lik);
LIK = -sum(lik);
xmean = mean(x);
bxmean = xmean * beta1(1:end-1)' + beta1(end);
yhatmean = 1 ./ (1+ exp(-bxmean));
for i = 1:cx,
pderiv(:,i)  = mean(yhat .* (1-yhat) .* beta1(i));
end;