function [error, yhat, pderiv,neuron3] = jerryautofun2a(beta);
global data1 squasher maxx minx maxy miny;
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
ny = length(yy);
yhat1 = yy; 
xx1 = xx * beta(1:cx)' + ones(rx,1) * beta(2*cx+1);
xx2 = xx * beta(cx+1:2*cx)' + ones(rx,1) * beta(2*cx+2);
neuron1 = xx1;
neuron2 = xx2;
neuron3 =  1 ./ (1 + exp(-beta(2*cx+3)* xx(:,end)));
yhat1 = neuron3 * neuron1 + (1- neuron3) *   neuron2; 
end;
nparm = 2 * cx + 15;
error = yy - yhat1;
error = sum(error .^2);
sigma = error/ nparm;  
T = length(yhat1);          
loglik = 0;
error = -loglik;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
for i = 1:cx,
for j = 2:ny,
    pderiv(j,i) =  neuron3(j,1) .* neuron1(j,1) .* (1-neuron1(j,1)) * beta(i) + (1-neuron3(j,1)) .*  neuron2(j,1) .* (1-neuron2(j,1)) * beta(cx+i); 
end;
end;
    




