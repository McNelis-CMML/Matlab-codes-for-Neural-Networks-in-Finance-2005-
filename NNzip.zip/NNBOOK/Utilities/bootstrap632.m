function [W1,w1best,w2best,w3best, w4best,meansse1, meansse3, ssebest,rsqbest,rmsqbest,hqifbest,pderbest,...
      epsilon0_ls, epsilon0_net, omega632_ls, omega632_net, ssebootstrap_ls, ssebootstrap_net, foutput,exitflag, nparm] = ...
   bootstrap632(assetx,target,nlag,delay,info,gendum,maxgen, nepoch, helge,derdum,delta, ndraws);
% Ouputs:
%     output: Wols,W1net,W2net,W3net, W4net
%             meansse1 meansse3
%             sse, rsq, rmsq, hqif, pderiv , 
%             epsilon0_ls, epsilon0_net, omega632_ls, 
%             omega632_net sseboot_ls sseboot_net
%             foutput, exitflag, nparm
%				  
% Inputs:
%      Input matrix,
%      column of dep variable,  
%      number of lags
%		 delay factor (forecasting more than one period ahead
%      info:  no of  hidden layers, neurons in 1 , 2, 3, (3 max)
%      gendum:  
%          genetic algorithm with gd (=1),ga off, gd on (=0); just ga, gd off (=2)
%      maxgen:  number of generations for ga
%      nepoch:  number of epochs or iterations for function optimizer
%      dummy for squasher, 1 for helge, 2 for DeLeo (zlogsig), 3 Matlab, 0 for none
% 		 dummy for partial derivative, 0 for mean, 1 for endpoint
%      delta:  difference for evaluating partial derivatives
%      number of draws from bootstrap

global P T nlayer nneuron1 nneuron2 nneuron3;
warning off;
nntwarn off;
percent = 1;
nlayer = info(1);
nneuron1 = info(2);
nneuron2 = info(3);
nneuron3 = info(4);
popsize = 50; 
pc = .9; pdes = 0; 
toler = .001; 
elite = 1;
[rr cc] = size(assetx);
% nlag = 1;   % number of lags and arguments.
yrhat = [assetx];
if nlag == 0,
   y = assetx(1+delay:end,target); 
   x = assetx(:,target(end)+1:end,:); 
   x = x(1:end-delay,:);
else
   [y x] = mylagvv(assetx, nlag, target, delay);
end;
yxmat = [y x];
   [nrow ncol] = size(x);
   [nrowy ncoly] = size(y);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = [ x(1:nrow1,:)];
[nrow ncol] = size(x);
nrow1 = round(percent * nrow);
nrow11 = nrow1 + 1; [nrow12 nrow13] = size(x(1:nrow1,:));
yy = y(1:nrow1,:); xx = x(1:nrow1,:);
smin = .1;
smax = .9;
[rx, cx] = size(x);
[ry, cy] = size(y);
maxy = max(y);
miny = min(y);
maxx = max(x);
minx = min(x);
meany = mean(y);
sigy = std(y);
yz = detrend(y) ./ kron(ones(rx,1), sigy);
meanx = mean(x);
sigx = std(x);
xz = detrend(x) ./ kron(ones(rx,1),sigx);;
for i = 1:cy,
   ys(:,i) = hsquasher(y(:,i), smax, smin);
   yss(:,i) = logsig(yz(:,i));
end
for i = 1:cx,
   xs(:,i) = hsquasher(x(:,i), smax, smin);
   xss(:,i) = logsig(xz(:,i));
end
if helge == 0, PN = x'; TN = y'; 
elseif helge == 1, PN = xs'; TN = ys';
elseif helge == 2, PN = xss'; TN = yss';
else 
   PP = x'; TT = y';
   [PN,minp,maxp,TN,mint,maxt] = premnmx(PP,TT);
end
Praw = xx';
Traw = yy';
P = PN(:,1:nrow1);
T = TN(:,1:nrow1);
[rowp, colp] = size(P);
[W1,b1] = solvelin(Praw,Traw);
A1 = simulin(Praw, W1,b1);
bols = b1;
err1 = Traw - A1; 
err1 = err1'; 
TTT = Traw';
sse1 = sum(err1 .^ 2);

meansse1 = mean(err1 .^2);
Als = A1;
yhatls = Als';
[yyr yyc] = size(yhatls);
% ssrsq1 = var(yhatls) ./ var(yy);
err1 = yy - yhatls; 
ssrsq1 = ones(1,yyc) - var(err1) ./ var(yy);
sse1 = sum (err1 .^ 2);
hqols = nrow1 * log(sse1) + (ncol+1) * log(log(nrow1));
[rp,cp] = size(P);

if nlayer == 1, nparm = nneuron1*rp + nneuron1 ...
        + nneuron1 * ncoly + ncoly;
elseif nlayer == 2, nparm = nneuron1 * rp + nneuron1 ...
        + nneuron1 * nneuron2 +  nneuron2 +  nneuron2 * ncoly + ncoly;
else nparm = nneuron1 * rp + nneuron1 + nneuron1 * nneuron2 ...
        + nneuron2 + nneuron2 * nneuron3 +  nneuron3 + nneuron3 * ncoly + ncoly;
end

scale = 1; 
beta0 = randn(1,nparm);
tp = [25, nepoch, .02, .01, 1.07, .7, .9, 1.04]; 
pm = .33; elite = 1; pdes = 0; 
if gendum >= 1, beta = ...
   genetic5('emnetg1xx',nparm,popsize,maxgen,pc,pm,elite,pdes,maxgen + 10,toler, scale, beta0);
   else beta = .01 * ones(1, nparm); end
[criterion,sse3,g,A3,W3,b3,W4,b4, W5, b5, W6, b6] = emnetg1xx(beta);
if gendum <= 1,
% [W3,b3,W4,b4] = trainbpx(W3,b3,'logsig',W4,b4,'purelin',P,T,tp);
%	 options(1) = 1; options(14) = nepoch;  
% options = optimset('Display','iter', 'MaxFunEvals', nepoch, 'MaxIter', nepoch,...
%   'TolFun', delta);
options = optimset('MaxFunEvals', nepoch, 'MaxIter', nepoch,...
   'TolFun', delta);
[beta,foutput,exitflag] = fminunc('emnetg1xx', beta, options);
tstatn = tstatapp('emnetg1xx', beta, delta);
   [criterion,sse3,g,A3, W3,b3,W4,b4, W5, b5, W6, b6] = emnetg1xx(beta);
else W3=W3; b3 = b3; W4 = W4; b4 = b4; W5 = W5, b5 = b5, W6 = W6, b6 = b6; end
if helge == 0, A3n = A3; 
elseif helge == 1, A3 = A3';
   for i = 1:cy,
      A3x(:,i) = helgeyx(A3(:,i), maxy(i), miny(i),smax,smin);
   end
   A3 = A3';
   A3n = A3x'; 
elseif helge == 2, A3 = A3';
    A3x = antilogsig(A3);
    A3x = real(A3x); [junkr, junkc] = size(A3x);
    A3x = kron(ones(junkr,1),meany) + A3x .* kron(ones(junkr,1),sigy);
    A3 = A3';
    A3n = A3x'; A3n = real(A3n);
else A3n = postmnmx(A3,mint, maxt);
   end
yhatnet = A3n';
ydep = yy;
err3 = ydep - yhatnet;
sse3 = sum(err3 .^2);
meansse3 = mean(err3 .^2);
hqnet = nrow1 .* log(sse3) + (nparm) * log(log(nrow1));
% ssrsq3 = var(yhatnet) ./ var(ydep);
ssrsq3 = ones(1,yyc) - var(err3) ./ var(yy);
sse = [sse1; sse3];
hqif = [hqols; hqnet];
ssrsq = [ssrsq1; ssrsq3];
xxmean = mean(xx);

xxend = xx(end,:);
if derdum == 0, xstar = xxmean; else xstar = xxend; end
if helge == 0, pstar = xstar;
elseif helge == 1, 
   for i = 1:cx,
      pstar(1,i) = hsquasher(xstar(1,i), smax, smin, maxx(1,i), minx(1,i));
      end
  elseif helge == 2, pstar = logsig((xstar - meanx)./ sigx); pstar = real(pstar);
else pstar = (xstar - minx) ./ (maxx - minx); 
end
pstar = pstar';

hdelta = delta;
hdeltav = eye(rowp) * hdelta;
if nlayer == 1,  A3star = feval('logsig', W3 * pstar,b3');
   A3star = feval('purelin', W4 * A3star, b4'); 
elseif nlayer == 2,
   A3star = feval('logsig', W3 * pstar, b3');
   A3star = feval('logsig', W4 * A3star, b4');
   A3star = feval('purelin', W5 * A3star, b5');
else
   A3star = feval('logsig', W3 * pstar, b3');
   A3star = feval('logsig', W4 * A3star, b4');
   A3star = feval('logsig', W5 * A3star, b5');
   A3star = feval('purelin', W6 * A3star, b6');
end
if helge == 0, A3star = A3star;
elseif helge == 1, 
   A3star = A3star';
   for ii = 1:cy,
      A3star(:,ii) = helgeyx(A3star(:,ii),maxy(1,ii), miny(1,ii),smax, smin);
   end
   A3star = A3star';
elseif helge == 2,
    A3star = A3star';
    A3star = antilogsig(A3star);
    A3star = meany + A3star .* sigy;
    A3star = A3star';
   else  A3star = postmnmx(A3star,mint, maxt);
   end
   

for i = 1: rowp,
   xdel = xstar + hdeltav(i,:);
   if helge == 0, pstardel = xdel;
   elseif helge == 1, 
      for j = 1:cx,
         pstardel(1,j) = hsquasher(xdel(1,j), smax, smin, maxx(1,j), minx(1,j)); 
      end  
  elseif helge == 2,
      pstardel = logsig((xdel - meanx) ./ sigx); pstardel = real(pstardel);
   else 
      for jj = 1:cx,
         pstardel(1,jj) = (xdel(1,jj) - minx(1,jj)) ./ (maxx(1,jj) - minx(1,jj));
      end
      
   end
   pstardel = pstardel';   
   pstardel = pstardel(:,1);
   if nlayer == 1,  A3d = feval('logsig', W3 * pstardel,b3');
   A3d = feval('purelin', W4 * A3d, b4'); 
elseif nlayer == 2,
   A3d = feval('logsig', W3 * pstardel, b3');
   A3d = feval('logsig', W4 * A3d, b4');
   A3d = feval('purelin', W5 * A3d, b5');
else
   A3d = feval('logsig', W3 * pstardel, b3');
   A3d = feval('logsig', W4 * A3d, b4');
   A3d = feval('logsig', W5 * A3d, b5');
   A3d = feval('purelin', W6 * A3d, b6');
end
if helge == 0, A3d = A3d;
elseif helge == 1, 
   A3d = A3d';
   for kk = 1:cy,
      A3d(1,kk) = helgeyx(A3d(1,kk), maxy(kk), miny(kk),smax,smin);
   end
   A3d = A3d';
   A3d = real(A3d);
elseif helge == 2,
    A3d = A3d';
    A3d = antilogsig(A3d);
    A3d = meany + A3d .* sigy;
    A3d = A3d'; A3d = real(A3d);
else  A3d = postmnmx(A3d,mint, maxt);
   end
   pdernum(i,:) = -(A3star' - A3d') ./hdelta;
   clear A3d xdel;   
   
end
pdernum = pdernum';

w1net = W3;
w2net = W4;
w3net = W5;
w4net = W6;
hqnet = hqif(ncoly+1:end,:);
pdernetc = pdernum; 
ssebest = sse;
rsqbest = [ssrsq];
hqifbest = [hqif];
pderbest = [W1; pdernetc];
w1best = w1net;
w2best = w2net;
w3best = w3net;
w4best = w4net;
b1best = b3;
b2best = b4;
b3best = b5;
b4best = b6;

for i = 1:ndraws,
    
clear global P T;
global P T;
indexin = ceil(rand(nrow1,1) * nrow1);
indexin = sort(indexin);
for j=1:nrow1, 
    if sum(ismember(indexin,i)) > 0,
        indexout(j,:) = NaN;
    else indexout(j,:) = j;
    end
end
indexout = excise(indexout);
xx = PN';
yy = TN';
xin = xx(indexin,:);
yin = yy(indexin,:);
P = xin';
T = yin';
[W1,b1] = solvelin(P,T);
if gendum >= 1, beta = ...
   genetic5('emnetg1xx',nparm,popsize,maxgen,pc,pm,elite,pdes,maxgen + 10,toler, scale, beta0);
   else beta = .01 * ones(1, nparm); end
[criterion,sse3,g,A3,W3,b3,W4,b4, W5, b5, W6, b6] = emnetg1xx(beta);
if gendum <= 1,
% [W3,b3,W4,b4] = trainbpx(W3,b3,'logsig',W4,b4,'purelin',P,T,tp);
%	 options(1) = 1; options(14) = nepoch;  
% options = optimset('Display','iter', 'MaxFunEvals', nepoch, 'MaxIter', nepoch,...
%   'TolFun', delta);
options = optimset('MaxFunEvals', nepoch, 'MaxIter', nepoch,...
   'TolFun', delta);
[beta,foutput,exitflag] = fminunc('emnetg1xx', beta, options);
[criterion,sse3,g,A3, W3,b3,W4,b4, W5, b5, W6, b6] = emnetg1xx(beta);
else W3=W3; b3 = b3; W4 = W4; b4 = b4; W5 = W5, b5 = b5, W6 = W6, b6 = b6; end

clear xout yout P1 T1 A11 yhats1 err11 err11sq A31 A31z A31x A31net yhatnet1;
xout  = xx(indexout,:);
yout = yy(indexout,:);
[n1 c1] = size(yout);
Poutraw = xout';
Toutraw = yout';
T1 = Toutraw;
P1 = Poutraw;
A11 = simulin(Poutraw,W1);
yhatls1 = A11';
err11 = yout - yhatls1;
err11sq = err11 .^2;
rmsqe1 = sqrt(mean(err11sq));
if nlayer == 1,  A31 = feval('logsig', W3 * P1,b3');
   A31 = feval('purelin', W4 * A31, b4'); 
elseif nlayer == 2,
   A31 = feval('logsig', W3 * P1, b3');
   A31 = feval('logsig', W4 * A31, b4');
   A31 = feval('purelin', W5 * A31, b5');
else
   A31 = feval('logsig', W3 * P1, b3');
   A31 = feval('logsig', W4 * A31, b4');
   A31 = feval('logsig', W5 * A31, b5');
   A31 = feval('purelin', W6 * A31, b6');
end
if helge == 0, yhatnet1 = A31';
elseif helge == 1, A31z = A31';
   for i = 1:cy,
      A31x(:,i) = helgeyx(A31z(:,i), maxy(i), miny(i),smax,smin);
   end
   A31net = A31x'; yhatnet1 = A31net';
elseif helge == 2,
    A31z = A31';
    A31x = antilogsig(A31z); A31x = real(A31x);
    A31x = kron(ones(n1,1),meany) + A31x .* kron(ones(n1,1), sigy);
    A31net = A31x'; yhatnet1 = A31net';
else  A31net = postmnmx(A31,mint, maxt);
   	yhatnet1 = A31net';
end


yyy = [yy yhatls yhatnet; yout yhatls1 yhatnet1]; 
yyy = real(yyy);
yyyhat = yyy(1:nrow1,:);
yyyout = yyy(nrow1+1:end,:);
yout = yyyout;
ndim = ncoly;
for jj = 1:ndim,
   erroroutls(:,jj) = yout(:,ndim+jj) - yout(:,jj); 
   erroroutnet(:,jj) = yout(:,2*ndim+jj) - yout(:,jj); 
   rrmsq(1,jj) = sqrt(mean(erroroutls(:,jj) .^2));
   rrmsq(2,jj) = sqrt(mean(erroroutnet(:,jj) .^2));
end
rmsqbest = rrmsq;
yout = yout(:,1:ndim);
err31 = yout-yhatnet1;
err31sq = err31 .^2;
rmsqe3 = (mean(err31sq)) .^ .5;
rmsqe = [rmsqe1; rmsqe3];
RMSQE(:,:,i) = rmsqe;
SQLS(i,:) = mean(err11sq);
SQNET(i,:) = mean(err31sq);

if isnan(SQLS(i,:)) == 1, SQLS(i,:) = []; 
else SQLS(i,:) = SQLS(i,:); 
end;

if isnan(SQNET(i,:)) == 1, SQNET(i,:) = []; 
else SQNET(i,:) = SQNET(i,:); 
end;

end
rmsqbest = RMSQE;
epsilon0_ls = mean(SQLS);
epsilon0_net = mean(SQNET);
omega632_ls = .632 * (epsilon0_ls - meansse1);
omega632_net = .632 * (epsilon0_net - meansse3);
ssebootstrap_ls =  meansse1 + omega632_ls;
ssebootstrap_net = meansse3 + omega632_net;




clear global P T nlayer nneuron1 nneuron2 nneuron3;