function [GARCHMAT, condvariance] = mygarch(series, r, m, p, q);
% Inputs:  series, r,m,p,q for AR - MA - GARCH - ARCH order
% Outputs: garch stats, and condvariance
spec = garchset('R',r,'M',m,'P',p,'Q',q);
[gcoeff1, gstdev1, gllf1, ginnov1, gsigma1] = garchfit(spec, series);
gcoeff11 = gcoeff1;
gstdev11 = gstdev1;
condvariance = gsigma1;
k11 = getfield(gcoeff11,'K'); 
garch11 = getfield(gcoeff11, 'GARCH'); 
arch11 = getfield(gcoeff11,'ARCH'); 
k11sig = getfield(gstdev11,'K'); 
garch11sig = getfield(gstdev11, 'GARCH'); 
arch11sig = getfield(gstdev11,'ARCH'); 
k11tstat = k11 ./ k11sig;
garch11tstat = garch11 ./ garch11sig;
arch11tstat = arch11 ./ arch11sig;
GARCHMAT = [k11 k11sig k11tstat garch11 garch11sig garch11tstat arch11 arch11sig arch11tstat];
