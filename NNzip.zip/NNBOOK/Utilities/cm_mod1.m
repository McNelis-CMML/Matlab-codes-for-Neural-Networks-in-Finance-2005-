function [error, yhat, Jstat, Jsig, neuron1] = cm_mod1_gmm(beta);
global squasher data1 minx miny maxx maxy malags neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol ;

y = data1(:,1);
x = data1(:,2:end-1);
z = mylag(x, malags);
y = y(malags+1:end,:);
x = x(malags+1:end,:);
[nx, cx] = size(x);
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg_inf = (cthres_inf-minx(neuronxarg_inf)) / (maxx(neuronxarg_inf)-minx(neuronxarg_inf));
else cxarg_inf = cthres_inf;
end
ny = length(yy);
xx1 = xx * (beta(1:cx))' + ones(ny,1) * abs((beta(cx+1)));
neuronx = abs(beta(cx+2))* (xx(:,neuronxarg_inf)-cxarg_inf);
neuron1 =  2 ./ (1 + exp(-2 * neuronx))-1;
yhat1 = xx1  + neuron1 * beta(neuronxarg_inf) * xx(:,neuronxarg_inf);
nparm =  cx + 2;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
ehat = y - yhat;
[nz, cz] = size(z);
mm = z' * ehat / ny;
mhat = mm(:);
mm1 = repmat(ehat,1, cz) .* z;
vm = neweywest(mm1, malags);
error = mm' * vm * mm;
Jstat = error * ny;
dgf = cz - length(beta);
Jsig = 1 - chi2cdf(Jstat, dgf);






