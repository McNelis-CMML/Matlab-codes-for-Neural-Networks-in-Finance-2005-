function [error, yhat, pderiv,neuron3] = carlosfun(beta);
global data1 squasher maxx minx maxy miny malags;
y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);

ny = length(y);
yhat(1:malags,:) = y(1:malags,:);
ehat(1:malags,:) = zeros(malags,1);
x1(1:malags,:) = x(1:malags,:) * beta(1:cx)' + ones(malags,1) * beta(cx+1);
neuron1(1:malags,:) = 1 ./ (1+exp(-x1(1:malags,:)));
for i = malags+1:ny,
    EXX = ehat(i-malags:i-1,:);
    x1(i,:) =  x(i,:) * beta(1:cx)' + beta(cx+1)  + beta(cx+2:cx+1+malags) * EXX; 
    neuron1(i,:) = 1 ./ (1+ exp(-x1(i,:)));
 
%     yhat(i,:) =   neuron1(i,:) +  1./(1+ exp(-beta(cx+2:cx+1+malags) * EXX));
%   yhat(i,:) =   neuron1(i,:) +  abs(beta(cx+2:cx+1+malags) * EXX);
    yhat(i,:) =   neuron1(i,:); 
    ehat(i,:) = y(i,:)- yhat(i,:);; 
end
yhat = real(yhat);
nparm = cx + 1 + malags;
lik = yhat .^ y .* (1-yhat) .* (1-y);
loglik = sum(log(lik));
error = -loglik;
for i = 1:cx,
    pderiv(:,i) =  neuron1 .* (1-neuron1) * beta(i); 
end;



