function [error, yhat, pderiv] = linearmodfun(beta);
global data1 squasher malags;
y = data1(:,1);
x = data1(:,2:end-1);
[nx, cx] = size(x);
% beta(1:cx+1) = abs(beta(1:cx+1));
[nx, cx] = size(x);
ny = length(y);
yhat1 = y; 
ehat(1:malags,1) = zeros(malags,1);
xx0 = x * abs(beta(1:cx))' + ones(ny,1) * abs(beta(cx+1));
for i = malags+1:ny, 
EXX = ehat(i-malags:i-1,:);
beta(cx+2:end);
yhat1(i,:) =  xx0(i,:) +  beta(cx + 3: end) * EXX;
ehat(i,:) = y(i,:) - yhat1(i,:);
end;
yhat = yhat1;    
nparm = cx + malags + 1;
error = y - yhat;
error1 = (error .^2);
T = length(yhat); 
sigma = sum(error1)/ (T-nparm);  
loglik = -.5 * T * log(2 * pi) - .5 * T * log(sigma) - .5 * inv(sigma) *  sum((error).^2) ;
error = -loglik;
pderiv = abs(beta(1:cx));






