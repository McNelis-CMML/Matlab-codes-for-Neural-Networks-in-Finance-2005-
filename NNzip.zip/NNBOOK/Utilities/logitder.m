function pderivl = logitder(pbar, beta);
% pderivl = logitder(pbar, beta);
yy = exp(beta(1:end-1) * pbar+ beta(end));
pderivl = (yy / (1 + yy) ^2) .* beta(1:end-1);