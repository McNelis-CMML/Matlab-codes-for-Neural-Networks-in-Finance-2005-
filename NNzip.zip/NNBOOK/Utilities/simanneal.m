function [beta,sseb, beta1] = simanneal(fun,beta,T0, norm);
%  Simulated Annealing Program
%  Inputs: function,initial weight, temperature
%  Output: weight
if nargin < 4, norm = 1; end;
weight(1,:) = beta;
nparm = cols(beta);
sse(1) = feval(fun,beta);
T(1) = T0 / (1 + log(1));
j = 1;
[j T(1) sse(1)];
for j = 2:T0,
   T(j) = T0 / (1 + log(j));
cutpoint = round(rand(1,1) * (nparm-1)) + 1; 
dw = randn(1,1) * norm;
% dw = tansig(dw);
w1 = weight(j-1,:); w1(:,cutpoint) = w1(:,cutpoint) + dw;
sse(j) = feval(fun,w1);
dsse = sse(j) - sse(j-1);
metro(j) = exp(-dsse/T(j));
pm = rand(1,1);
if dsse < 0 & pm > metro(j), weight(j,:) = w1; 
elseif dsse < 0  & pm < metro(j), weight(j,:) = w1;
elseif dsse > 0 & pm > metro(j), weight(j,:) = w1;
else weight(j,:) = weight(j-1,:); end;
[j T(j) sse(j) metro(j)]
end;
[sseb, ind] = min(sse);
beta = weight(ind,:);
beta1 = weight(end,:);