function [diebold, msig] = dieboldmar(x1,x2,p);
%  Diebold - Mariano Statistic for Differences in Forecast Errors
%  Reference:  "Comparing Predictive Accuracy" ,
%  Francix X. Diebold and Roberto S. Mariano
%  Journal of Business and Economic Statistics, July 1995, vol 3, No 3,
%  page 253-263 
 zz = abs(x1) - abs(x2);
 [p1 cc] = size(zz); 
% zzlag = mylag(zz, p);
% zzz = [zz(p+1:end,:) zzlag]; 
% junk = cov(zzz); 
% zzz = zz(p+1,end,:);
% zzsq = zzz .^ 2;
%  sumzzsq = sum(zzsq);
autorho = covariog(zz,p);
rhosq = autorho;
% for j = 1:p-1, ttjj(j) = j/p;; end;
% ttjj = -p:1:p; ttjj = ttjj'; ttjj = abs(ttjj);
% rhosqj = (ttjj ./ p) .* rhosq;
% denom = sum(rhosqj);
denom = sum(rhosq) /p1;
denom1 =sqrt(denom);
diebold = mean(zz) / denom1;
diebold = real(diebold);
msig = 1 - normcdf(diebold);

