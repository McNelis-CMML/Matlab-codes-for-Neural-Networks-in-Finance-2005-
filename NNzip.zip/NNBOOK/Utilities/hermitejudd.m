function hhxx = hermitejudd(x, degree);
[rx, cx] = size(x);
hhxx(:,1) = ones(rx,1);
hhxx(:,2) = 2*x;
for i = 3:degree,
    hhxx(:,i) = 2 .* x .* hhxx(:,i-1) - 2 .* (i-1) .* hhxx(:,i-2);
end
hhxx = hhxx(:,2:end);