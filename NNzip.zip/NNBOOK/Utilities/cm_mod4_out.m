function [error, yhat] = cm_mod4_out(beta);
global squasher data1 minx miny maxx maxy malags neuronxarg_ygap cthres_ygap neuronxarg_inf cthres_inf neuronxarg_yvol cthres_yvol ;

y = data1(:,1);
x = data1(:,2:end);
[nx, cx] = size(x);
cx = cx-1;
% beta(1:2*cx+3) = abs(beta(1:2*cx+3));
if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx+1, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
if squasher == 1,
    cxarg_yvol = (cthres_yvol-minx(neuronxarg_yvol)) / (maxx(neuronxarg_yvol)-minx(neuronxarg_yvol));
else cxarg_yvol = cthres_yvol;
end

ny = length(yy);
yhat1 = yy; 
xx1 = xx(:,1:cx) * abs(beta(1:cx))' + ones(ny,1) * abs(beta(cx+1));
ehat(1:malags,1) = zeros(malags,1); 
neuron1(1:malags,1) = zeros(malags,1); 
for i = malags+1:ny, 
neuronx = abs(beta(cx+2))* (xx(i-1,neuronxarg_yvol)-cxarg_yvol);
neuron1(i,:) =  2 ./ (1 + exp(-2 * neuronx)) -1;
EXX = ehat(i-malags:i-1,:);
yhat1(i,:) = xx1(i,:)  - neuron1(i,:) * abs(beta(neuronxarg_ygap)) * xx(i,neuronxarg_ygap)  + beta(cx + 3:cx+malags+2) * EXX;
ehat(i,:) = yy(i,:) - yhat1(i,:);
end;
error = 0;
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
    




