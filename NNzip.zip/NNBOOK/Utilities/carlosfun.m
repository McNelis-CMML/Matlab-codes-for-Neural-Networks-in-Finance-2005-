function [error, yhat, pderiv,neuron3] = carlosfun(beta);
global data1 squasher maxx minx maxy miny malags;
y = data1(:,1);
x = data1(:,2:end);

[nx, cx] = size(x);

if squasher == 1,
    yy = (y - miny)/(maxy-miny);
    for i = 1:cx, xx(:,i) = (x(:,i)-minx(i))/(maxx(i)-minx(i));
    end
else yy = y; xx = x;
end
ny = length(yy);
yhat1(1:malags,:) = yy(1:malags,:);
neuron3(1:malags,:) = .5 * ones(malags,1);
ehat(1:malags,:) = zeros(malags,1);
xx1(1:malags,:) = xx(1:malags,:) * beta(1:cx)';
xx2(1:malags,:) = xx(1:malags,:) * beta(cx+1:2*cx)';
xx11(1:malags,:) = xx1(1:malags,:) + beta(2*cx+1);
xx21(1:malags,:) = xx2(1:malags,:) + beta(2*cx+2);
neuron1(1:malags,:) = 1 ./ (1+exp(-xx11(1:malags,:)));
neuron1(1:malags,:) = 1 ./ (1+exp(-xx21(1:malags,:)));
% for i = 13:ny,
%     neuron3(i,:) =  1 ./(1+ exp(-beta(2*cx+3) * xx(i,end-2)));
%     EXX = ehat(i-malags:i-1,:);
%     xx11(i,:) =  xx(i,:) * beta(1:cx)' + beta(2*cx+1) + beta(2*cx+4:2*cx+15) * EXX;
%     xx21(i,:) =  xx(i,:) * beta(2*cx+1)' + beta(2*cx+2) * beta(2*cx+16: 2*cx+27) * EXX;
%     neuron1(i,:) = 1 ./ (1+ exp(-xx11(i,:)));
%     neuron2(i,:) = 1 ./ (1+ exp(-xx21(i,:)));
%     yhat1(i,:) =  neuron3(i,:) * neuron1(i,:) + (1-neuron3(i,:)) * neuron2(i,:);
%     ehat(i,:) = yy(i,:) - yhat(i,:);
% end


for i = malags+1:ny,
    neuron3(i,:) =  1 ./(1+ exp(-beta(2*cx+3) * xx(i,end-2)));
    EXX = ehat(i-malags:i-1,:);
    xx11(i,:) =  xx(i,:) * beta(1:cx)' + beta(2*cx+1) + beta(2*cx+4:2*cx+3+malags) * EXX;; 
    xx21(i,:) =  xx(i,:) * beta(cx+1:2*cx)' + beta(2*cx+2) + beta(2*cx+4:2*cx+3+malags) * EXX;;
    neuron1(i,:) = 1 ./ (1+ exp(-xx11(i,:)));
    neuron2(i,:) = 1 ./ (1+ exp(-xx21(i,:)));
%   yhat1(i,:) =  neuron3(i,:) * neuron1(i,:) + (1-neuron3(i,:)) * neuron2(i,:) + 1 ./(1+ exp(-beta(2*cx+4:2*cx+3+malags) * EXX));
    yhat1(i,:) =  neuron3(i,:) * neuron1(i,:) + (1-neuron3(i,:)) * neuron2(i,:); 
%    
    ehat(i,:) = yy(i,:) - yhat1(i,:);
end
yhat1 = real(yhat1);
if squasher == 1,
    yhat = yhat1 * (maxy-miny) + miny;
else yhat = yhat1;
end;
nparm = 2 * cx + 3 + malags;
lik = yhat .^ y .* (1-yhat) .* (1-y);
loglik = sum(log(lik));
error = -loglik;
for i = 1:cx,
    pderiv(:,i) =  neuron3 .* neuron1 .* (1-neuron1) * beta(i) + (1-neuron3) .*  neuron2 .* (1-neuron2) * beta(cx+i); 
end;







