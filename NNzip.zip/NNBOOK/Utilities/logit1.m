 function [LIK,ssr,y,pderiv] = logit(beta1);
 global data1;
 y = data1(:,1);
 x = data1(:,2:end);
bx = x * beta1(1:end-1)' + ones(length(y),1) * beta1(end);
yhat = 1 ./ (1 + exp(bx));
ssr = (y - yhat)' * (y-yhat);
[rr cc] = size(T);
for i = 1:cc,
    lik(i) = (yhat(i,:).^(1-y(i,:)))* (y(i,:)^(T(i)));

end
yy = exp(beta(1:end-1) * pbar+ beta(end));
pderivl = (yy / (1 + yy) ^2) .* beta(1:end-1);
LIK = - sum(log(lik));
LIK = real(LIK);
