function [LIK, ssr, yhat, pderiv] = gompit(beta);
global P T;
[rr cc] = size(T);
[rx, cx] = size(P);
y = T; x = P;
beta1 = beta;
nn =  P * beta1(1:end-1)' + ones(length(P),1) * beta1(end);
yhat =  exp(-exp(-nn));
ssr = (T - yhat)' * (T-yhat);
y = T;
lik =  real(y .* log(yhat) + (1-y) .* log(1-yhat));
LIK = -sum(lik);
% lik = yhat .^ y .* (1-yhat) .^ (1-y);
% LIK = prod(lik);
xmean = mean(x);
yhatmean = xmean * beta1(1:end-1)' + beta(end);
for i= 1:cx,
pderiv(i) = mean(exp(yhat) .* exp(-yhatmean) .* beta1(i));
end
