function y = hsquasher1(x, ymax, ymin, xmax, xmin);
%  squasher function developed by Helge Petersohn
%  inputs:  x, ymax, ymin
[rr cc] = size(x);
if nargin == 3,
xmax = max(x);
xmin = min(x);
else xmax = xmax; xmin = xmin;
end
ymax = ymax * ones(cc);
ymin = ymin * ones(cc);
for i = 1:cc,
A(i)= log((1 / ymax(i)) - 1) - log((1/ymin(i)) - 1);
A(i) = A(i) / (xmax(i) - xmin(i));
B(i) = log((1/ymin(i)) - 1);
y(:,i) = 1 ./ (1 + exp(A(i) * (x(:,i) - xmin(i)) + B(i)));
end
