function [loglik, yhat] = linearmodfun_mlik(beta);
global data1 squasher malags nwlags nwestdum;
% beta(1) = 1 / (1+exp(-beta(1)));
y = data1(:,1);
x = data1(:,2:end-1);
[nx, cx] = size(x);
% beta(1:cx+1) = abs(beta(1:cx+1));
[nx, cx] = size(x);
ny = length(y);
bb = abs(beta(1:cx));
bb1 = beta(cx+1);
if malags > 0,
ehat(1:malags,1) = zeros(malags,1);
end;
yhat = x * bb' + ones(ny,1) * bb1;
ehat = y - yhat;
if malags > 0,
for i = malags+1:ny, 
EXX = ehat(i-malags:i-1,:);
yhat(i,:) =  yhat(i,:) +  beta(cx + 2: end) * EXX;
ehat(i,:) = y(i,:) - yhat(i,:);
end;
end;
nparm = cx + malags + 1;
error = ehat;  
errorsq = (error .^2);
T = length(yhat); 
sigmavar = sum(errorsq)/ (T-nparm);  
sigmastd = sqrt(sigmavar);
errornorm = error ./ sigmastd;
loglik1 = -.5 * T * log(2 * pi) - .5 * T * log(sigmavar) - .5 *  sum((errornorm).^2) ;
loglik = -loglik1;






